"use strict"

const SELLER_OS_ORIGIN =
  "https://imnova-seller-os-preprod.vercel.app"
const CONTROL_PAGE = `${SELLER_OS_ORIGIN}/admin/ebay/luna-shipping-capture`
const PORT_NAME = "SELLER_OS_LUNA_SHIPPING_CAPTURE_V1"
const JOB_RESULT = "LUNA_SHIPPING_JOB_RESULT"
const CONTRACT = "LUNA_SHIPPING_QUOTE_CAPTURE_V1"
const EXACT_EXTENSION_ID = "mhpkojahbbfdgodeaecggpjaplllgclk"
const EXTENSION_PING = "SELLER_OS_LUNA_SHIPPING_PING"
const EXTENSION_READY = "LUNA_SHIPPING_EXTENSION_READY"
const EXTENSION_BUILD_VERSION = "1.0.57"
const WORKER_CONTROL_ALARM = "seller-os-luna-shipping-worker-control-v1"
const JOB_TIMEOUT_ALARM = "seller-os-luna-shipping-job-timeout-v1"
const JOB_RESUME = "SELLER_OS_LUNA_SHIPPING_JOB_RESUME"
const GET_ACTIVE_JOB = "GET_ACTIVE_LUNA_SHIPPING_JOB"
const JOB_PROGRESS = "LUNA_SHIPPING_JOB_PROGRESS"
const JOB_RUNTIME_FAILURE = "LUNA_SHIPPING_JOB_RUNTIME_FAILURE"
const SET_ACTIVE_JOB_PHASE = "SET_ACTIVE_LUNA_SHIPPING_JOB_PHASE"
const CHECKOUT_NAVIGATION_TRIGGER = "LUNA_CHECKOUT_NAVIGATION_TRIGGERED"
const CHECKOUT_BOOTSTRAP_ACK = "SHOP_APP_CHECKOUT_BOOTSTRAP_ACK"
const RESUME_ACTIVE_JOB = "RESUME_ACTIVE_LUNA_SHIPPING_JOB"
const BIND_CANONICAL_DESTINATION_EXECUTE =
  "BIND_CANONICAL_DESTINATION_EXECUTE_V1"
const BIND_EXECUTION_CONTRACT = "LUNA_CANONICAL_DESTINATION_BIND_EXECUTION_V1"
const BIND_ELIGIBILITY_PROBE =
  "SELLER_OS_LUNA_BIND_ELIGIBILITY_PROBE_V1"
const BIND_ELIGIBILITY_CONTRACT = "LUNA_BIND_ELIGIBILITY_PROBE_V1"
const GET_CANONICAL_DESTINATION_BINDING =
  "GET_LUNA_CANONICAL_DESTINATION_BINDING"
const AUTO_BIND_CANONICAL_DESTINATION =
  "AUTO_BIND_LUNA_CANONICAL_DESTINATION_V1"
const AUTO_BIND_CONTRACT = "LUNA_CANONICAL_DESTINATION_AUTO_BIND_V1"
const GET_CANONICAL_DESTINATION_STATUS =
  "SELLER_OS_GET_LUNA_CANONICAL_DESTINATION_STATUS"
const CANONICAL_DESTINATION_STATUS =
  "LUNA_CANONICAL_DESTINATION_STATUS"
const GET_BINDING_STORAGE_DIAGNOSTIC =
  "SELLER_OS_GET_LUNA_BINDING_STORAGE_DIAGNOSTIC_V1"
const BINDING_STORAGE_DIAGNOSTIC =
  "LUNA_BINDING_STORAGE_DIAGNOSTIC_V1"
const DESTINATION_BINDING_RESULT =
  "LUNA_CANONICAL_DESTINATION_BINDING_RESULT"
const DESTINATION_FINGERPRINT_VERSION =
  "LUNA_SHOP_PAY_DESTINATION_SHA256_V1"
const PROFILE_DESTINATION_FINGERPRINT_VERSION =
  "LUNA_CANONICAL_DESTINATION_PROFILE_SHA256_V1"
const DESTINATION_AUTHORITY_CLASS =
  "OPERATOR_BOUND_CANONICAL_US_DESTINATION_V1"
const DESTINATION_EVIDENCE_CLASS =
  "SERVER_CANONICAL_DESTINATION_PROFILE_DIGEST"
const DESTINATION_VALIDATION_METHOD = "EXACT_PROFILE_DIGEST_MATCH"
const DESTINATION_STORAGE_KEY = "sellerOsLunaCanonicalDestinationBindingV1"
const DESTINATION_STORAGE_AUTHORITY =
  `chrome.storage.local:${DESTINATION_STORAGE_KEY}`
const RUNTIME_TRACE_CONTRACT = "LUNA_SHIPPING_RUNTIME_TRACE_V1"
const RUNTIME_TRACE_EVENT = "LUNA_SHIPPING_RUNTIME_TRACE_EVENT"
const SHIPPING_SERVER_RESULT = "SELLER_OS_LUNA_SHIPPING_SERVER_RESULT"
const GET_ACTIVE_PRODUCTION_JOB_STATUS =
  "SELLER_OS_GET_ACTIVE_LUNA_SHIPPING_JOB_STATUS"
const ACTIVE_PRODUCTION_JOB_STATUS = "LUNA_SHIPPING_ACTIVE_JOB_STATUS"
const DURABLE_DISPATCH_ACK = "SELLER_OS_LUNA_SHIPPING_DURABLE_DISPATCH_ACK"
const JOB_DISPATCH_ACK = "LUNA_SHIPPING_JOB_DISPATCH_ACK"
const EXTENSION_DISPATCH_RECEIVED =
  "LUNA_SHIPPING_EXTENSION_DISPATCH_RECEIVED"
const PORT_HANDSHAKE = "SELLER_OS_LUNA_SHIPPING_PORT_HANDSHAKE_V1"
const PORT_HANDSHAKE_ACK = "LUNA_SHIPPING_PORT_HANDSHAKE_ACK_V1"
const PAGE_DISPATCH_COMMITTED =
  "SELLER_OS_LUNA_SHIPPING_PAGE_DISPATCH_COMMITTED"
const CANCEL_ACTIVE_JOB = "SELLER_OS_CANCEL_LUNA_SHIPPING_JOB_V1"
const OWNED_RUN_CONTEXTS_STORAGE_KEY =
  "sellerOsLunaOwnedRunContextsV1"
const MAX_RUNTIME_TRACE_EVENTS = 100
const CART_PHASE = "AWAITING_CART_CONFIRMATION"
const CHECKOUT_PHASE = "AWAITING_CHECKOUT_SHIPPING"
const JOB_MAX_RUNTIME_MS = 10 * 60 * 1_000
const CHECKOUT_BOOTSTRAP_ACK_TIMEOUT_MS = 2_500
const BIND_STEP_TIMEOUT_MS = 2_000
const BIND_TOP_FRAME_TIMEOUT_MS = 25_000
const BIND_CONTENT_RESPONSE_TIMEOUT_MS = 5_000
const BIND_CHECKOUT_BOOTSTRAP_TIMEOUT_MS = 90_000
const CHECKOUT_NAVIGATION_OBSERVATION_TIMEOUT_MS = 20_000
const MAX_BIND_DISCOVERY_TABS = 200
const CHECKOUT_HOSTS = new Set(["lunaportex.com", "www.lunaportex.com",
  "account.lunaportex.com", "shop.app"])
const SHOP_APP_HOST_PATTERN = "https://shop.app/*"
const CHECKOUT_STATE_RANK = new Map([
  ["SHIPPING_FLOW_RESUMED", 5], [CHECKOUT_PHASE, 6],
  ["CHECKOUT_NAVIGATION_ARMED", 7],
  ["CHECKOUT_NAVIGATION_TRIGGERED", 8],
  ["CHECKOUT_NAVIGATION_TIMEOUT", 9],
  ["CHECKOUT_NAVIGATION_OBSERVED", 10], ["CHECKOUT_HOST_ALLOWED", 11],
  ["CHECKOUT_INJECTION_REQUESTED", 20],
  ["CHECKOUT_INJECTION_API_SUCCEEDED", 21],
  ["CHECKOUT_SCRIPT_INJECTED", 22], ["CHECKOUT_SCRIPT_BOOTSTRAP_ACK", 30],
  ["CHECKOUT_CONTENT_SCRIPT_LOADED", 40], ["CONTENT_SCRIPT_LOADED", 40],
  ["ACTIVE_JOB_REQUESTED", 45], ["ACTIVE_JOB_RECOVERED_ON_CHECKOUT", 50],
  ["CHECKOUT_CLASSIFIER_STARTED", 60], ["CHECKOUT_HOST_CLASSIFIED", 70],
  ["CHECKOUT_PAGE_DETECTED", 75],
  ["SHOP_PAY_DOM_WAITING", 80], ["SHOP_PAY_DOM_READY", 90],
  ["CHECKOUT_PAGE_CLASSIFIED", 100],
  ["NORMAL_CHECKOUT_WITH_SHIPPING", 102], ["UNKNOWN_CHECKOUT_PAGE", 102],
  ["CHECKOUT_EXPECTED_PRODUCT_VERIFIED", 103],
  ["CHECKOUT_EXPECTED_QUANTITY_VERIFIED", 104],
  ["CANONICAL_US_PROFILE_FOUND", 105],
  ["SHOP_PAY_QUOTE_PARSER_STARTED", 110], ["SHIPPING_CAPTURE_STARTED", 111],
  ["SHIPPING_ADDRESS_ACCEPTED", 112], ["SHIPPING_OPTIONS_DETECTED", 113],
  ["SHIPPING_QUOTE_CAPTURED", 120], ["RESULT_POSTED", 130],
  ["AUTHENTICATED_OPERATION_CONFIRMED", 121],
])

let sellerPort = null
let activeTabId = null
let activeJob = null
let lastRuntimeState = null
let activeJobPhase = null
let originalCartSnapshot = null
let cartSubtotalUsd = null
let checkoutNavigationArmed = false
let checkoutNavigationTriggered = false
let checkoutInjectionStarted = false
let checkoutBootstrapAckReceived = false
let checkoutBootstrapAckEmitted = false
let checkoutBootstrapAckTimer = null
let lastCheckoutStateRank = 0
let lastCheckoutState = null
let activeJobTimeoutTimer = null
let activeJobStartedAtMs = null
let jobTerminationInProgress = false
let lastOwnedContextCleanup = Object.freeze({
  reason: "NOT_RUN", orphanOwnedTabsAfterRun: 0,
  orphanOwnedWindowsAfterRun: 0,
})
let terminalCleanupChain = Promise.resolve(lastOwnedContextCleanup)
const ownedRunTabs = new Map()
const ownedRunWindows = new Map()
let ownedRunContextsHydration = null
let activeRuntimeTrace = null
let canonicalBindInFlight = false
let canonicalBindBootstrapActive = false
let canonicalBindCheckoutWaiter = null
let canonicalBindBootstrapTraceStates = new Set()
let canonicalBindBootstrapAttempted = false
let checkoutNavigationObservation = null
let checkoutNavigationObservationTimer = null
let pendingExactDispatch = null
let completedExactDispatchTraceId = null
let exactDispatchMessageReceivedCandidateId = null
let exactDispatchAckEmittedCandidateId = null

const PROGRESS_TRACE_STATE = new Map([
  ["PRODUCT_PAGE_DOM_READY", "PRODUCT_PAGE_OPENED"],
  ["PRODUCT_IDENTITY_VERIFIED", "PRODUCT_IDENTITY_VERIFIED"],
  ["PRODUCT_OOS_CONFIRMED", "PRODUCT_OOS_CONFIRMED"],
  ["ADD_TO_CART_ELEMENT_FOUND", "ADD_TO_CART_FOUND"],
  ["ADD_TO_CART_CLICK_DISPATCHED", "ADD_TO_CART_DISPATCHED"],
  ["CART_PAGE_DETECTED", "CART_PAGE_DETECTED"],
  ["ACTIVE_JOB_RECOVERED_ON_CART", "ACTIVE_JOB_RECOVERED_ON_CART"],
  ["CART_EXPECTED_PRODUCT_FOUND", "CART_PRODUCT_VERIFIED"],
  ["CART_EXPECTED_QUANTITY_FOUND", "CART_QUANTITY_VERIFIED"],
  ["CART_MUTATION_CONFIRMED", "CART_MUTATION_CONFIRMED"],
  ["CHECKOUT_NAVIGATION_ARMED", "CHECKOUT_NAVIGATION_ARMED"],
  ["CHECKOUT_NAVIGATION_TRIGGERED", "CHECKOUT_NAVIGATION_TRIGGERED"],
  ["CHECKOUT_NAVIGATION_TIMEOUT", "CHECKOUT_NAVIGATION_TIMEOUT"],
  ["CHECKOUT_NAVIGATION_OBSERVED", "CHECKOUT_NAVIGATION_OBSERVED"],
  ["CHECKOUT_HOST_CLASSIFIED", "CHECKOUT_HOST_CLASSIFIED"],
  ["CHECKOUT_HOST_ALLOWED", "CHECKOUT_HOST_CLASSIFIED"],
  ["CHECKOUT_INJECTION_REQUESTED", "CHECKOUT_SCRIPT_INJECTION_REQUESTED"],
  ["CHECKOUT_INJECTION_API_SUCCEEDED", "CHECKOUT_SCRIPT_INJECTION_RESULT"],
  ["CHECKOUT_SCRIPT_BOOTSTRAP_ACK", "CHECKOUT_BOOTSTRAP_ACK"],
  ["ACTIVE_JOB_RECOVERED_ON_CHECKOUT", "ACTIVE_JOB_RECOVERED_ON_CHECKOUT"],
  ["SHOP_PAY_DOM_READY", "SHOP_PAY_DOM_READY"],
  ["CHECKOUT_PAGE_CLASSIFIED", "CHECKOUT_PAGE_CLASSIFIED"],
  ["CHECKOUT_PAGE_DETECTED", "CHECKOUT_PAGE_CLASSIFIED"],
  ["NORMAL_CHECKOUT_WITH_SHIPPING", "CHECKOUT_PAGE_CLASSIFIED"],
  ["CANONICAL_US_PROFILE_FOUND", "CANONICAL_DESTINATION_MATCH"],
  ["SHOP_PAY_QUOTE_PARSER_STARTED", "QUOTE_PARSER_STARTED"],
])

async function sha256(value) {
  const bytes = new TextEncoder().encode(String(value))
  const result = await crypto.subtle.digest("SHA-256", bytes)
  return `sha256:${Array.from(new Uint8Array(result))
    .map((byte) => byte.toString(16).padStart(2, "0")).join("")}`
}

async function beginRuntimeTrace(seed, candidateId) {
  const captureSessionIdHash = await sha256(seed)
  activeRuntimeTrace = {
    traceId: `luna-shipping-trace-v1:${captureSessionIdHash}`,
    captureSessionIdHash,
    candidateId: /^sha256:[0-9a-f]{64}$/.test(candidateId ?? "")
      ? candidateId : null,
    sequence: 0,
    events: [],
  }
}

async function adoptExactPreDispatchRuntimeTrace(event, job) {
  const captureSessionIdHash = await sha256(job.captureSessionId)
  const timestampMs = Date.parse(String(event?.timestamp ?? ""))
  if (!event || event.contractVersion !== RUNTIME_TRACE_CONTRACT ||
      event.traceId !== `luna-shipping-trace-v1:${captureSessionIdHash}` ||
      event.candidateId !== job.identity.candidateId || event.sequence !== 1 ||
      event.extensionVersion !== EXTENSION_BUILD_VERSION ||
      event.captureSessionIdHash !== captureSessionIdHash ||
      event.state !== "EXACT_JOB_RESOLVED" ||
      event.event !== "EXACT_JOB_RESOLVED" || event.success !== true ||
      event.reasonCode !== "NONE" || event.purchaseBoundaryEnforced !== true ||
      !Number.isFinite(timestampMs) || timestampMs > Date.now() + 60_000 ||
      Date.now() - timestampMs > 10 * 60 * 1_000) {
    throw new Error("LUNA_EXACT_DISPATCH_PRETRACE_INVALID")
  }
  return {
    traceId: event.traceId,
    captureSessionIdHash,
    candidateId: job.identity.candidateId,
    sequence: 1,
    events: [Object.freeze({
      contractVersion: RUNTIME_TRACE_CONTRACT,
      traceId: event.traceId,
      candidateId: job.identity.candidateId,
      sequence: 1,
      timestamp: new Date(timestampMs).toISOString(),
      extensionVersion: EXTENSION_BUILD_VERSION,
      captureSessionIdHash,
      state: "EXACT_JOB_RESOLVED",
      event: "EXACT_JOB_RESOLVED",
      success: true,
      reasonCode: "NONE",
      purchaseBoundaryEnforced: true,
    })],
  }
}

function traceMoney(value) {
  return Number.isFinite(value) && value >= 0 && value <= 100_000
    ? Math.round(value * 100) / 100 : null
}

function emitRuntimeTrace(state, success = true, reasonCode = "NONE", details = {}) {
  if (!activeRuntimeTrace ||
      activeRuntimeTrace.sequence >= MAX_RUNTIME_TRACE_EVENTS) return
  activeRuntimeTrace.sequence += 1
  const event = {
    contractVersion: RUNTIME_TRACE_CONTRACT,
    traceId: activeRuntimeTrace.traceId,
    candidateId: activeRuntimeTrace.candidateId,
    sequence: activeRuntimeTrace.sequence,
    timestamp: new Date().toISOString(),
    extensionVersion: EXTENSION_BUILD_VERSION,
    captureSessionIdHash: activeRuntimeTrace.captureSessionIdHash,
    state, event: state, success,
    reasonCode: safeRuntimeReason(reasonCode).toUpperCase(),
    purchaseBoundaryEnforced: true,
  }
  for (const field of ["subtotalUsd", "shippingUsd", "totalUsd"]) {
    const value = traceMoney(details[field])
    if (value !== null) event[field] = value
  }
  for (const field of ["shopPayMarkerShipTo", "shopPayMarkerShipping",
    "shopPayMarkerSubtotal", "shopPayMarkerTotal", "shopPayMarkerPayNow"]) {
    if (typeof details[field] === "boolean") event[field] = details[field]
  }
  for (const field of ["bindCheckoutBootstrapRequired",
    "bindCheckoutBootstrapAttempted", "bindStartJobInvoked"]) {
    if (typeof details[field] === "boolean") event[field] = details[field]
  }
  if (details.productOosConfirmed === true) event.productOosConfirmed = true
  if (details.productPageStockStatus === "FRESH_OUT_OF_STOCK") {
    event.productPageStockStatus = "FRESH_OUT_OF_STOCK"
  }
  for (const field of ["subtotalLabelFound", "subtotalAmountCandidateFound",
    "subtotalCurrencyFound", "subtotalParsed", "shippingLabelFound",
    "shippingAmountCandidateFound", "shippingCurrencyFound", "shippingParsed",
    "totalLabelFound", "totalAmountCandidateFound", "totalCurrencyFound",
    "totalParsed"]) {
    if (typeof details[field] === "boolean") event[field] = details[field]
  }
  for (const field of ["tabsQueryTotalCount", "shopAppHostTabCount",
    "shopAppProbedCount", "tabsEnumeratedCount",
    "contentScriptResponderCount", "eligibleCheckoutCount",
    "probeAttemptCount", "probeResponseCount", "eligibleResponseCount",
    "probeErrorCount", "bindCheckoutDiscoveryValidCount"]) {
    const value = details[field]
    if (Number.isInteger(value) && value >= 0 && value <= 10_000) {
      event[field] = value
    }
  }
  activeRuntimeTrace.events.push(event)
  try { sellerPort?.postMessage({ type: RUNTIME_TRACE_EVENT, event }) } catch {
    // The bounded trace remains buffered and is replayed on bridge reconnect.
  }
}

function traceProgress(state, details) {
  const traceState = PROGRESS_TRACE_STATE.get(state)
  if (traceState) emitRuntimeTrace(traceState, true, "NONE", details)
  if (state === "SHIPPING_QUOTE_CAPTURED") {
    emitRuntimeTrace("SUBTOTAL_PARSED", true, "NONE", details)
    emitRuntimeTrace("SHIPPING_PARSED", true, "NONE", details)
    emitRuntimeTrace("TOTAL_PARSED", true, "NONE", details)
  }
}

function emitBindBootstrapTraceOnce(state) {
  if (!canonicalBindBootstrapActive ||
      canonicalBindBootstrapTraceStates.has(state)) return
  canonicalBindBootstrapTraceStates.add(state)
  emitRuntimeTrace(state)
}

function waitForCanonicalBindCheckout() {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      if (canonicalBindCheckoutWaiter?.timer !== timer) return
      canonicalBindCheckoutWaiter = null
      reject(new Error("BIND_CHECKOUT_BOOTSTRAP_TIMEOUT"))
    }, BIND_CHECKOUT_BOOTSTRAP_TIMEOUT_MS)
    canonicalBindCheckoutWaiter = { resolve, reject, timer }
  })
}

function settleCanonicalBindCheckout(error = null) {
  const waiter = canonicalBindCheckoutWaiter
  if (!waiter) return
  canonicalBindCheckoutWaiter = null
  clearTimeout(waiter.timer)
  if (error) waiter.reject(error)
  else waiter.resolve()
}

function resetCheckoutNavigationObserver() {
  if (checkoutNavigationObservationTimer) {
    clearTimeout(checkoutNavigationObservationTimer)
  }
  checkoutNavigationObservationTimer = null
  checkoutNavigationObservation = null
}

function initializeCheckoutNavigationObserver(job) {
  resetCheckoutNavigationObserver()
  checkoutNavigationObservation = {
    captureSessionId: job.captureSessionId,
    armed: false,
    observed: false,
    tabId: null,
    host: null,
    origin: null,
  }
}

function armCheckoutNavigationObserver() {
  if (!activeJob || !checkoutNavigationObservation ||
      checkoutNavigationObservation.captureSessionId !==
        activeJob.captureSessionId) return false
  checkoutNavigationObservation.armed = true
  if (checkoutNavigationObservationTimer) {
    clearTimeout(checkoutNavigationObservationTimer)
  }
  const captureSessionId = activeJob.captureSessionId
  checkoutNavigationObservationTimer = setTimeout(() => {
    checkoutNavigationObservationTimer = null
    if (!activeJob || activeJob.captureSessionId !== captureSessionId ||
        !checkoutNavigationObservation?.armed ||
        checkoutNavigationObservation.observed) return
    emitProgress("CHECKOUT_NAVIGATION_TIMEOUT")
    failBindingBootstrapOrActiveJob(checkoutNavigationTriggered
      ? "CHECKOUT_NAVIGATION_NOT_OBSERVED"
      : "CHECKOUT_NAVIGATION_NOT_TRIGGERED")
  }, CHECKOUT_NAVIGATION_OBSERVATION_TIMEOUT_MS)
  emitProgress("CHECKOUT_NAVIGATION_ARMED")
  return true
}

function markCheckoutNavigationTriggered() {
  if (!activeJob || !checkoutNavigationObservation?.armed ||
      checkoutNavigationObservation.captureSessionId !==
        activeJob.captureSessionId) return false
  checkoutNavigationTriggered = true
  if (checkoutNavigationObservationTimer) {
    clearTimeout(checkoutNavigationObservationTimer)
  }
  const captureSessionId = activeJob.captureSessionId
  checkoutNavigationObservationTimer = setTimeout(() => {
    checkoutNavigationObservationTimer = null
    if (!activeJob || activeJob.captureSessionId !== captureSessionId ||
        !checkoutNavigationTriggered ||
        checkoutNavigationObservation?.observed) return
    emitProgress("CHECKOUT_NAVIGATION_TIMEOUT")
    failBindingBootstrapOrActiveJob("CHECKOUT_NAVIGATION_NOT_OBSERVED")
  }, CHECKOUT_NAVIGATION_OBSERVATION_TIMEOUT_MS)
  emitProgress("CHECKOUT_NAVIGATION_TRIGGERED")
  return true
}

function consumeRuntimeLastError() {
  return chrome.runtime?.lastError?.message ?? ""
}

function ephemeralOwnedContextStorageArea() {
  const area = chrome.storage?.session
  return area && typeof area.get === "function" &&
    typeof area.set === "function" ? area : null
}

function hydrateOwnedRunContexts() {
  if (ownedRunContextsHydration) return ownedRunContextsHydration
  const area = ephemeralOwnedContextStorageArea()
  if (!area) {
    ownedRunContextsHydration = Promise.resolve()
    return ownedRunContextsHydration
  }
  ownedRunContextsHydration = new Promise((resolve) => {
    try {
      area.get(OWNED_RUN_CONTEXTS_STORAGE_KEY, (stored) => {
        consumeRuntimeLastError()
        const envelope = stored?.[OWNED_RUN_CONTEXTS_STORAGE_KEY]
        for (const entry of Array.isArray(envelope?.tabs) ? envelope.tabs : []) {
          if (Number.isInteger(entry?.id) &&
              typeof entry?.captureSessionId === "string") {
            ownedRunTabs.set(entry.id, {
              captureSessionId: entry.captureSessionId,
              createdAt: String(entry.createdAt ?? ""),
            })
          }
        }
        for (const entry of Array.isArray(envelope?.windows)
          ? envelope.windows : []) {
          if (Number.isInteger(entry?.id) &&
              typeof entry?.captureSessionId === "string") {
            ownedRunWindows.set(entry.id, {
              captureSessionId: entry.captureSessionId,
              createdAt: String(entry.createdAt ?? ""),
            })
          }
        }
        resolve()
      })
    } catch { resolve() }
  })
  return ownedRunContextsHydration
}

function persistOwnedRunContexts() {
  const area = ephemeralOwnedContextStorageArea()
  if (!area) return Promise.resolve()
  const envelope = {
    version: 1,
    tabs: [...ownedRunTabs].map(([id, metadata]) => ({ id, ...metadata })),
    windows: [...ownedRunWindows]
      .map(([id, metadata]) => ({ id, ...metadata })),
  }
  return new Promise((resolve) => {
    try {
      area.set({ [OWNED_RUN_CONTEXTS_STORAGE_KEY]: envelope }, () => {
        consumeRuntimeLastError()
        resolve()
      })
    } catch { resolve() }
  })
}

async function registerOwnedRunTab(tabId, captureSessionId) {
  if (!Number.isInteger(tabId) || typeof captureSessionId !== "string") return
  await hydrateOwnedRunContexts()
  ownedRunTabs.set(tabId, { captureSessionId,
    createdAt: new Date().toISOString() })
  await persistOwnedRunContexts()
}

async function registerOwnedRunWindow(windowId, captureSessionId) {
  if (!Number.isInteger(windowId) || typeof captureSessionId !== "string") return
  await hydrateOwnedRunContexts()
  ownedRunWindows.set(windowId, { captureSessionId,
    createdAt: new Date().toISOString() })
  await persistOwnedRunContexts()
}

async function forgetOwnedRunTab(tabId) {
  await hydrateOwnedRunContexts()
  if (!ownedRunTabs.delete(tabId)) return
  await persistOwnedRunContexts()
}

function chromeContextExists(kind, id) {
  const api = kind === "window" ? chrome.windows : chrome.tabs
  if (!api || typeof api.get !== "function") return Promise.resolve(false)
  return new Promise((resolve) => {
    let settled = false
    const finish = (exists) => {
      if (settled) return
      settled = true
      resolve(exists)
    }
    try {
      const pending = api.get(id, (value) => {
        const error = consumeRuntimeLastError()
        finish(!error && Boolean(value))
      })
      pending?.then?.((value) => finish(Boolean(value)), () => finish(false))
    } catch { finish(false) }
  })
}

function removeChromeContext(kind, id) {
  const api = kind === "window" ? chrome.windows : chrome.tabs
  if (!api || typeof api.remove !== "function") return Promise.resolve(false)
  return new Promise((resolve) => {
    let settled = false
    const finish = (removed) => {
      if (settled) return
      settled = true
      resolve(removed)
    }
    try {
      const pending = api.remove(id, () => {
        const error = consumeRuntimeLastError()
        finish(!error || /No (?:tab|window)/i.test(error))
      })
      pending?.then?.(() => finish(true), () => finish(false))
    } catch { finish(false) }
  })
}

async function cleanupOwnedRunContexts(reason = "TERMINAL") {
  await hydrateOwnedRunContexts()
  const close = async (kind, entries) => {
    const survivors = []
    for (const id of entries) {
      let removed = false
      for (let attempt = 0; attempt < 3 && !removed; attempt += 1) {
        removed = await removeChromeContext(kind, id)
        if (!removed) removed = !await chromeContextExists(kind, id)
      }
      if (removed || !await chromeContextExists(kind, id)) {
        if (kind === "window") ownedRunWindows.delete(id)
        else ownedRunTabs.delete(id)
      } else survivors.push(id)
    }
    return survivors
  }
  // A whole OS-owned window is closed first. Individual owned tabs never
  // imply ownership of the surrounding user window.
  const orphanWindows = await close("window", [...ownedRunWindows.keys()])
  const orphanTabs = await close("tab", [...ownedRunTabs.keys()])
  await persistOwnedRunContexts()
  lastOwnedContextCleanup = Object.freeze({ reason,
    orphanOwnedTabsAfterRun: orphanTabs.length,
    orphanOwnedWindowsAfterRun: orphanWindows.length })
  return lastOwnedContextCleanup
}

function armActiveJobTimeout(startedAtMs = Date.now()) {
  if (activeJobTimeoutTimer) clearTimeout(activeJobTimeoutTimer)
  activeJobStartedAtMs = Number.isFinite(startedAtMs) ? startedAtMs : Date.now()
  const remaining = Math.max(0,
    JOB_MAX_RUNTIME_MS - (Date.now() - activeJobStartedAtMs))
  activeJobTimeoutTimer = setTimeout(() => {
    activeJobTimeoutTimer = null
    failActiveJob("LUNA_SHIPPING_JOB_TIMEOUT")
  }, remaining)
  activeJobTimeoutTimer?.unref?.()
  chrome.alarms?.create?.(JOB_TIMEOUT_ALARM, {
    when: activeJobStartedAtMs + JOB_MAX_RUNTIME_MS,
  })
}

function clearActiveJob() {
  if (activeJobTimeoutTimer) clearTimeout(activeJobTimeoutTimer)
  activeJobTimeoutTimer = null
  activeJobStartedAtMs = null
  try {
    chrome.alarms?.clear?.(JOB_TIMEOUT_ALARM, () => consumeRuntimeLastError())
  } catch { /* Alarm cleanup is best effort; activeJob remains authoritative. */ }
  resetCheckoutNavigationObserver()
  activeJob = null
  activeJobPhase = null
  originalCartSnapshot = null
  cartSubtotalUsd = null
  checkoutNavigationArmed = false
  checkoutNavigationTriggered = false
  checkoutInjectionStarted = false
  checkoutBootstrapAckReceived = false
  checkoutBootstrapAckEmitted = false
  if (checkoutBootstrapAckTimer) clearTimeout(checkoutBootstrapAckTimer)
  checkoutBootstrapAckTimer = null
  lastCheckoutStateRank = 0
  lastCheckoutState = null
  lastRuntimeState = null
  activeRuntimeTrace = null
  pendingExactDispatch = null
  completedExactDispatchTraceId = null
  exactDispatchMessageReceivedCandidateId = null
  exactDispatchAckEmittedCandidateId = null
  canonicalBindBootstrapActive = false
  canonicalBindBootstrapTraceStates = new Set()
  canonicalBindBootstrapAttempted = false
  settleCanonicalBindCheckout(new Error("BIND_CHECKOUT_BOOTSTRAP_ABORTED"))
}

async function terminateActiveJob(reason) {
  clearActiveJob()
  activeTabId = null
  const operation = terminalCleanupChain.then(async () => {
    jobTerminationInProgress = true
    try {
      return await cleanupOwnedRunContexts(safeRuntimeReason(reason))
    } finally {
      jobTerminationInProgress = false
    }
  })
  terminalCleanupChain = operation.catch(() => lastOwnedContextCleanup)
  return operation
}

function finalizeCanonicalBindRuntime(bootstrapStarted) {
  const bindTrace = activeRuntimeTrace
  if (bootstrapStarted || !activeJob) {
    clearActiveJob()
    activeTabId = null
  } else {
    canonicalBindBootstrapActive = false
    canonicalBindBootstrapTraceStates = new Set()
    canonicalBindBootstrapAttempted = false
    settleCanonicalBindCheckout(new Error("BIND_CHECKOUT_BOOTSTRAP_ABORTED"))
  }
  activeRuntimeTrace = bindTrace
  emitRuntimeTrace("BIND_RUNTIME_CLEARED")
}

function safeCartSnapshot(value) {
  if (!Array.isArray(value) || value.length > 50) return null
  const rows = value.map((entry) => ({
    id: String(entry?.id ?? ""), quantity: Number(entry?.quantity),
  }))
  return rows.every((entry) => /^\d{8,24}$/.test(entry.id) &&
    Number.isInteger(entry.quantity) && entry.quantity >= 1 &&
    entry.quantity <= 1_000) ? rows : null
}

function safeSellerSender(sender) {
  try {
    const url = new URL(sender?.origin ?? sender?.url ?? "")
    return url.protocol === "https:" && !url.username && !url.password &&
      !url.port && url.origin === SELLER_OS_ORIGIN
  } catch { return false }
}

function exactLunaUrl(value) {
  try {
    const url = new URL(value)
    const path = url.pathname.replace(/\/$/, "")
    const encodedHandle = path.startsWith("/products/")
      ? path.slice("/products/".length) : ""
    let handle = ""
    try { handle = decodeURIComponent(encodedHandle).normalize("NFKC") }
    catch { return null }
    const handleLength = Array.from(handle).length
    if (url.protocol !== "https:" ||
        !new Set(["lunaportex.com", "www.lunaportex.com"]).has(url.hostname) ||
        handleLength < 2 || handleLength > 255 ||
        /[\u0000-\u0020\u007f/\\?#]/u.test(handle) ||
        handle === "." || handle === ".." || /[A-Z]/.test(handle) ||
        url.username || url.password || url.port) return null
    url.hostname = "www.lunaportex.com"
    url.pathname = `/products/${encodeURIComponent(handle)}`
    url.search = ""
    url.hash = ""
    return url
  } catch { return null }
}

function safeNavigationIdentity(value) {
  if (typeof value !== "string") return null
  try {
    const url = new URL(value)
    if (url.protocol !== "https:" || url.username || url.password || url.port ||
        !/^[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?$/.test(url.hostname)) return null
    return { host: url.hostname, origin: `https://${url.hostname}` }
  } catch { return null }
}

function allowedCheckoutNavigation(value) {
  try {
    const url = new URL(value)
    if (url.protocol !== "https:" || !CHECKOUT_HOSTS.has(url.hostname)) return null
    const pathAllowed = new Set(["lunaportex.com", "www.lunaportex.com"])
      .has(url.hostname) ? /^\/checkouts?(?:\/|$)/.test(url.pathname)
      : true
    return pathAllowed ? { host: url.hostname,
      origin: `https://${url.hostname}` } : null
  } catch { return null }
}

function isPreNavigationCartDocument(value) {
  try {
    const url = new URL(value)
    return url.protocol === "https:" &&
      new Set(["lunaportex.com", "www.lunaportex.com"]).has(url.hostname) &&
      url.pathname.replace(/\/$/, "") === "/cart"
  } catch { return false }
}

function effectiveShopAppContract() {
  const manifest = chrome.runtime.getManifest()
  return manifest.version === EXTENSION_BUILD_VERSION &&
    Array.isArray(manifest.permissions) &&
    manifest.permissions.includes("storage") &&
    Array.isArray(manifest.host_permissions) &&
    manifest.host_permissions.includes(SHOP_APP_HOST_PATTERN) &&
    Array.isArray(manifest.content_scripts) &&
    manifest.content_scripts.some((entry) =>
      Array.isArray(entry.matches) && entry.matches.includes(SHOP_APP_HOST_PATTERN)) &&
    CHECKOUT_HOSTS.has("shop.app")
}

function jobValidationReason(value) {
  const job = value && typeof value === "object" ? value : {}
  const identity = job.identity && typeof job.identity === "object"
    ? job.identity : {}
  const destination = job.destination && typeof job.destination === "object"
    ? job.destination : {}
  if (!("contractVersion" in job)) return "JOB_MISSING_FIELD:contractVersion"
  if (job.contractVersion !== CONTRACT) return "JOB_INVALID_CONTRACT_VERSION"
  for (const [field, owner] of [
    ["captureSessionId", job], ["nonce", job], ["snapshotDigest", job],
    ["productName", job],
    ["salePriceUsd", job], ["supplierCostUsd", job],
    ["candidateId", identity], ["canonicalProductUrl", identity],
    ["lunaProductId", identity], ["lunaVariantId", identity],
    ["supplierSku", identity], ["quantity", identity],
    ["profileId", destination], ["profileDigest", destination],
    ["country", destination], ["province", destination],
    ["postalCode", destination],
  ]) if (!(field in owner)) return `JOB_MISSING_FIELD:${
    owner === identity ? "identity." : owner === destination ? "destination." : ""}${field}`
  if (typeof job.captureSessionId !== "string" || typeof job.nonce !== "string" ||
      typeof job.snapshotDigest !== "string" ||
      typeof job.productName !== "string" ||
      (job.salePriceUsd !== null && typeof job.salePriceUsd !== "number") ||
      typeof job.supplierCostUsd !== "number") return "JOB_INVALID_TYPE:job"
  if (typeof identity.candidateId !== "string" ||
      typeof identity.canonicalProductUrl !== "string" ||
      typeof identity.lunaProductId !== "string" ||
      typeof identity.lunaVariantId !== "string" ||
      typeof identity.supplierSku !== "string" ||
      typeof identity.quantity !== "number") return "JOB_INVALID_TYPE:identity"
  if (typeof destination.profileId !== "string" ||
      typeof destination.profileDigest !== "string" ||
      typeof destination.country !== "string" ||
      typeof destination.province !== "string" ||
      typeof destination.postalCode !== "string") return "JOB_INVALID_TYPE:destination"
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
      .test(job.captureSessionId)) return "JOB_INVALID_TYPE:captureSessionId"
  if (!/^sha256:[0-9a-f]{64}$/.test(job.snapshotDigest)) {
    return "JOB_INVALID_TYPE:snapshotDigest"
  }
  if (!/^\d{13}\.[A-Za-z0-9_-]{43}$/.test(job.nonce)) {
    return "JOB_INVALID_TYPE:nonce"
  }
  if (!/^sha256:[0-9a-f]{64}$/.test(identity.candidateId) ||
      !/^\d{8,24}$/.test(identity.lunaProductId) ||
      !/^\d{8,24}$/.test(identity.lunaVariantId) ||
      !/^[A-Za-z0-9][A-Za-z0-9._:+/ -]{0,159}$/.test(identity.supplierSku)) {
    return "JOB_IDENTITY_MISMATCH:identity"
  }
  if (!Number.isInteger(identity.quantity) || identity.quantity < 1 ||
      identity.quantity > 20) return "JOB_INVALID_TYPE:identity.quantity"
  if (!exactLunaUrl(identity.canonicalProductUrl)) {
    return "JOB_IDENTITY_MISMATCH:identity.canonicalProductUrl"
  }
  if (!/^[A-Z0-9_-]{3,80}$/.test(destination.profileId) ||
      !/^sha256:[0-9a-f]{64}$/.test(destination.profileDigest) ||
      destination.country !== "US" || !/^[A-Z]{2}$/.test(destination.province) ||
      !/^\d{5}(?:-\d{4})?$/.test(destination.postalCode)) {
    return "JOB_INVALID_TYPE:destination"
  }
  if ((job.salePriceUsd !== null &&
      (!Number.isFinite(job.salePriceUsd) || job.salePriceUsd <= 0)) ||
      !Number.isFinite(job.supplierCostUsd) || job.supplierCostUsd < 0 ||
      job.productName.trim().length < 2 || job.productName.length > 240) {
    return "JOB_INVALID_TYPE:commercialFacts"
  }
  return null
}

function safeJob(value) {
  return jobValidationReason(value) === null ? value : null
}

function sameJob(left, right) {
  return left?.captureSessionId === right?.captureSessionId &&
    left?.nonce === right?.nonce &&
    left?.identity?.candidateId === right?.identity?.candidateId
}

function encodeJob(job) {
  const bytes = new TextEncoder().encode(JSON.stringify(job))
  let binary = ""
  for (const byte of bytes) binary += String.fromCharCode(byte)
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "")
}

function decodeJobFromUrl(value) {
  try {
    const encoded = new URL(value).hash.slice(1)
      .split("&").map((entry) => entry.split("="))
      .find(([key]) => key === "seller-os-luna-shipping-v1")?.[1]
    if (!encoded || encoded.length > 12_000) return null
    const base64 = encoded.replace(/-/g, "+").replace(/_/g, "/") +
      "=".repeat((4 - encoded.length % 4) % 4)
    const binary = atob(base64)
    const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0))
    const decoded = JSON.parse(new TextDecoder().decode(bytes))
    return safeJob(decoded)
  } catch { return null }
}

function recoverActiveJob(sender) {
  if (!Number.isInteger(sender.tab?.id)) return null
  const navigatedJob = decodeJobFromUrl(sender.url ?? "")
  if (activeJob && navigatedJob && !sameJob(activeJob, navigatedJob)) return null
  if (!activeJob) {
    activeJob = navigatedJob
    if (activeJob) armActiveJobTimeout()
  }
  if (!activeJob) return null
  const expected = exactLunaUrl(activeJob.identity.canonicalProductUrl)
  let actual = null
  try { actual = new URL(sender.url ?? "") } catch { return null }
  const storefrontHost = new Set(["lunaportex.com", "www.lunaportex.com"])
    .has(actual.hostname)
  const productPath = expected && actual.pathname.replace(/\/$/, "") ===
    expected.pathname.replace(/\/$/, "")
  const cartPath = (activeJobPhase === CART_PHASE ||
    (activeJobPhase === CHECKOUT_PHASE && checkoutNavigationArmed &&
      !checkoutNavigationTriggered)) &&
    actual.pathname.replace(/\/$/, "") === "/cart"
  const lunaCheckout = storefrontHost && /^\/checkouts?(?:\/|$)/
    .test(actual.pathname)
  const accountCheckout = actual.hostname === "account.lunaportex.com"
  const shopPayCheckout = actual.hostname === "shop.app"
  const checkoutPath = activeJobPhase === CHECKOUT_PHASE &&
    checkoutNavigationArmed &&
    (lunaCheckout || accountCheckout || shopPayCheckout)
  if (!expected || actual.protocol !== "https:" ||
      ((!storefrontHost || (!productPath && !cartPath)) && !checkoutPath)) return null
  activeTabId = sender.tab.id
  return activeJob
}

function safeRuntimeReason(value) {
  return typeof value === "string" && /^[A-Za-z0-9_:.-]{3,120}$/.test(value)
    ? value : "LUNA_SHIPPING_RUNTIME_FAILURE"
}

function safeDestinationCandidate(value) {
  return value?.fingerprintVersion === DESTINATION_FINGERPRINT_VERSION &&
    /^sha256:[0-9a-f]{64}$/.test(value?.canonicalDestinationFingerprint ?? "") &&
    value?.countryClass === "US" ? Object.freeze({
      fingerprintVersion: value.fingerprintVersion,
      canonicalDestinationFingerprint: value.canonicalDestinationFingerprint,
      countryClass: "US",
    }) : null
}

function safeOperatorDestinationCandidate(value) {
  return value?.fingerprintVersion ===
      PROFILE_DESTINATION_FINGERPRINT_VERSION &&
    /^sha256:[0-9a-f]{64}$/.test(
      value?.canonicalDestinationFingerprint ?? "") &&
    value?.countryClass === "US" &&
    value?.authorityClass === DESTINATION_AUTHORITY_CLASS &&
    value?.evidenceClass === DESTINATION_EVIDENCE_CLASS &&
    value?.validationMethod === DESTINATION_VALIDATION_METHOD
    ? Object.freeze({
      fingerprintVersion: PROFILE_DESTINATION_FINGERPRINT_VERSION,
      canonicalDestinationFingerprint:
        value.canonicalDestinationFingerprint,
      countryClass: "US",
      authorityClass: DESTINATION_AUTHORITY_CLASS,
      evidenceClass: DESTINATION_EVIDENCE_CLASS,
      validationMethod: DESTINATION_VALIDATION_METHOD,
    }) : null
}

function safeDestinationBinding(value) {
  const candidate = safeOperatorDestinationCandidate(value)
  const boundAtMs = typeof value?.boundAt === "string"
    ? Date.parse(value.boundAt) : Number.NaN
  const boundAt = Number.isFinite(boundAtMs)
    ? new Date(boundAtMs).toISOString() : null
  return candidate && boundAt ? Object.freeze({ ...candidate, boundAt }) : null
}

function readDestinationBindingEnvelope() {
  return new Promise((resolve, reject) => chrome.storage.local.get(
    DESTINATION_STORAGE_KEY, (value) => {
      if (chrome.runtime.lastError) {
        reject(new Error("BINDING_STORAGE_READ_FAILED"))
        return
      }
      const present = Boolean(value && Object.prototype.hasOwnProperty.call(
        value, DESTINATION_STORAGE_KEY))
      resolve({ present, value: present ? value[DESTINATION_STORAGE_KEY] : null })
    }))
}

function bindingStorageDiagnostic() {
  const base = {
    type: BINDING_STORAGE_DIAGNOSTIC,
    extensionId: chrome.runtime.id,
    expectedExtensionId: EXACT_EXTENSION_ID,
    extensionVersion: chrome.runtime.getManifest().version,
    storageAreaUsed: "chrome.storage.local",
    writeStorageAuthority: DESTINATION_STORAGE_AUTHORITY,
    readStorageAuthority: DESTINATION_STORAGE_AUTHORITY,
    statusStorageAuthority: DESTINATION_STORAGE_AUTHORITY,
    autoClaimStorageAuthority: DESTINATION_STORAGE_AUTHORITY,
    authoritiesAligned: true,
    extensionIdContinuity: chrome.runtime.id === EXACT_EXTENSION_ID,
  }
  return readDestinationBindingEnvelope().then((stored) => {
    const envelope = stored.present && stored.value &&
      typeof stored.value === "object" ? stored.value : null
    const fingerprintPresent =
      typeof envelope?.canonicalDestinationFingerprint === "string" &&
      envelope.canonicalDestinationFingerprint.length > 0
    const countryClassPresent = typeof envelope?.countryClass === "string" &&
      envelope.countryClass.length > 0
    const boundAtPresent = typeof envelope?.boundAt === "string" &&
      envelope.boundAt.length > 0
    const schemaVersion = envelope?.fingerprintVersion ===
      PROFILE_DESTINATION_FINGERPRINT_VERSION
      ? PROFILE_DESTINATION_FINGERPRINT_VERSION
      : envelope?.fingerprintVersion == null ? "ABSENT" : "UNSUPPORTED"
    const current = safeDestinationBinding(envelope)
    let bindingClassification = "NO_BINDING_PRESENT"
    if (current) bindingClassification = "PRIMARY_BINDING_VALID"
    else if (stored.present && envelope?.fingerprintVersion !==
        PROFILE_DESTINATION_FINGERPRINT_VERSION) {
      bindingClassification = "BINDING_PRESENT_SCHEMA_REJECTED"
    } else if (stored.present) {
      bindingClassification = "BINDING_PRESENT_FIELD_REJECTED"
    }
    return {
      ...base,
      canonicalPrimaryKeyPresent: stored.present,
      canonicalLegacyKeyPresent: false,
      canonicalEnvelopePresent: Boolean(envelope),
      canonicalEnvelopeSchemaVersion: schemaVersion,
      canonicalEnvelopeValid: Boolean(current),
      canonicalCountryClassPresent: countryClassPresent,
      canonicalBoundAtPresent: boundAtPresent,
      canonicalFingerprintPresent: fingerprintPresent,
      storageReadStatus: "READ_OK",
      bindingClassification,
    }
  }, () => ({
    ...base,
    canonicalPrimaryKeyPresent: false,
    canonicalLegacyKeyPresent: false,
    canonicalEnvelopePresent: false,
    canonicalEnvelopeSchemaVersion: "NOT_READ",
    canonicalEnvelopeValid: false,
    canonicalCountryClassPresent: false,
    canonicalBoundAtPresent: false,
    canonicalFingerprintPresent: false,
    storageReadStatus: "BINDING_STORAGE_READ_FAILED",
    bindingClassification: "STORAGE_READ_FAILED",
  }))
}

async function readDestinationBinding() {
  const stored = await readDestinationBindingEnvelope()
  if (!stored.present) return null
  const current = safeDestinationBinding(stored.value)
  if (current) return current
  throw new Error("BINDING_PRESENT_INVALID")
}

function boundedBindStep(promise, transition, timeoutMs = BIND_STEP_TIMEOUT_MS) {
  return new Promise((resolve, reject) => {
    let settled = false
    const timer = setTimeout(() => {
      if (settled) return
      settled = true
      reject(new Error(`BIND_TIMEOUT:${transition}`))
    }, timeoutMs)
    Promise.resolve(promise).then((value) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve(value)
    }, (error) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      reject(error)
    })
  })
}

function writeDestinationBinding(binding) {
  return new Promise((resolve, reject) => chrome.storage.local.set({
    [DESTINATION_STORAGE_KEY]: binding,
  }, () => {
    if (chrome.runtime.lastError) {
      reject(new Error("BIND_STORAGE_WRITE_FAILED"))
      return
    }
    resolve()
  }))
}

async function autoBindCanonicalDestination() {
  throw new Error("CANONICAL_DESTINATION_EXPLICIT_OPERATOR_BIND_REQUIRED")
}

function operatorDestinationCandidateFromJob(job) {
  const exact = safeJob(job)
  if (!exact || exact.destination.country !== "US") {
    throw new Error("CANONICAL_DESTINATION_PROFILE_AUTHORITY_INVALID")
  }
  return safeOperatorDestinationCandidate({
    fingerprintVersion: PROFILE_DESTINATION_FINGERPRINT_VERSION,
    canonicalDestinationFingerprint: exact.destination.profileDigest,
    countryClass: "US",
    authorityClass: DESTINATION_AUTHORITY_CLASS,
    evidenceClass: DESTINATION_EVIDENCE_CLASS,
    validationMethod: DESTINATION_VALIDATION_METHOD,
  })
}

async function bindOperatorCanonicalDestination(existingBinding, bootstrapJob) {
  const candidate = operatorDestinationCandidateFromJob(bootstrapJob)
  if (!candidate) {
    throw new Error("CANONICAL_DESTINATION_PROFILE_AUTHORITY_INVALID")
  }
  if (existingBinding &&
      existingBinding.canonicalDestinationFingerprint !==
        candidate.canonicalDestinationFingerprint) {
    throw new Error("CANONICAL_US_SHIPPING_PROFILE_MISMATCH")
  }
  emitRuntimeTrace("CANONICAL_FINGERPRINT_COMPUTED")
  const binding = existingBinding ?? Object.freeze({ ...candidate,
    boundAt: new Date().toISOString() })
  if (!existingBinding) {
    emitRuntimeTrace("CANONICAL_FINGERPRINT_WRITE_STARTED")
    await boundedBindStep(writeDestinationBinding(binding),
      "CANONICAL_FINGERPRINT_WRITE_STARTED")
    emitRuntimeTrace("CANONICAL_FINGERPRINT_WRITE_COMPLETE")
  }
  const readback = await boundedBindStep(readDestinationBinding(),
    "CANONICAL_FINGERPRINT_READBACK_VERIFIED")
  if (!readback || readback.canonicalDestinationFingerprint !==
      binding.canonicalDestinationFingerprint ||
      readback.authorityClass !== DESTINATION_AUTHORITY_CLASS ||
      readback.evidenceClass !== DESTINATION_EVIDENCE_CLASS) {
    throw new Error("BIND_STORAGE_READBACK_MISMATCH")
  }
  emitRuntimeTrace("CANONICAL_FINGERPRINT_READBACK_VERIFIED")
  emitRuntimeTrace("CANONICAL_DESTINATION_MATCH")
  emitRuntimeTrace("CANONICAL_BIND_COMPLETED")
  return { type: DESTINATION_BINDING_RESULT, success: true,
    canonicalDestinationBound: true, canonicalDestinationMatch: true,
    canonicalUsProfileFound: true,
    operation: existingBinding ? "VALIDATE_CANONICAL_DESTINATION"
      : "BIND_CANONICAL_DESTINATION" }
}

function sendTabMessage(tabId, message, documentId) {
  return new Promise((resolve, reject) => {
    if (!Number.isInteger(tabId)) {
      reject(new Error("BIND_CHECKOUT_TAB_ID_INVALID"))
      return
    }
    chrome.tabs.sendMessage(tabId, message, documentId ? { documentId } : { frameId: 0 }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error("CHECKOUT_CONTENT_SCRIPT_NOT_AVAILABLE"))
        return
      }
      resolve(response)
    })
  })
}

function queryTabs(queryInfo) {
  return new Promise((resolve, reject) => chrome.tabs.query(queryInfo, (tabs) => {
    if (chrome.runtime.lastError) {
      reject(new Error("CANONICAL_BINDING_CHECKOUT_TAB_DISCOVERY_FAILED"))
      return
    }
    resolve(Array.isArray(tabs) ? tabs : [])
  }))
}

async function queryAccessibleTabIds() {
  const tabs = await queryTabs({})
  if (tabs.length > MAX_BIND_DISCOVERY_TABS) {
    throw new Error("BIND_TAB_ENUMERATION_LIMIT_EXCEEDED")
  }
  return {
    totalCount: tabs.length,
    tabs: tabs.filter((tab) => Number.isInteger(tab?.id))
      .map((tab) => ({ id: tab.id })),
  }
}

// Observation-only recovery. No job, binding, cart or navigation authority.
const checkoutObserverAttempts = new Map()
const CHECKOUT_OBSERVER_RETRY_MS = 15 * 60 * 1000
function checkoutRecoveryError(error) {
  const text = String(error?.message ?? error ?? '')
  if (/permission|Cannot access|not allowed/i.test(text)) return 'HOST_PERMISSION_DENIED'
  if (/No tab|tab.*closed/i.test(text)) return 'TAB_CLOSED'
  if (/frame|document/i.test(text)) return 'FRAME_UNAVAILABLE'
  if (/load file|resource|file.*not/i.test(text)) return 'SCRIPT_RESOURCE_UNAVAILABLE'
  if (/context invalidated/i.test(text)) return 'EXTENSION_CONTEXT_INVALIDATED'
  if (/TIMEOUT/i.test(text)) return 'INJECTION_TIMEOUT'
  return 'INJECTION_API_ERROR'
}
function checkoutChromeRead(invoke) {
  return new Promise((resolve, reject) => invoke(value => {
    const error = chrome.runtime.lastError
    if (error) reject(new Error(error.message || 'CHROME_API_ERROR'))
    else resolve(value)
  }))
}
async function checkoutObserverHello(tabId, documentId) {
  const nonce = crypto.randomUUID()
  try {
    const answer = await boundedBindStep(sendTabMessage(tabId, {
      type: 'SELLER_OS_LUNA_CHECKOUT_OBSERVER_HELLO_V1', nonce,
    }, documentId), 'CHECKOUT_OBSERVER_HELLO', BIND_CONTENT_RESPONSE_TIMEOUT_MS)
    return answer?.contract === 'LUNA_CHECKOUT_OBSERVER_HANDSHAKE_V1' &&
      answer.nonce === nonce && answer.version === EXTENSION_BUILD_VERSION && answer.loaded === true
  } catch { return false }
}
async function recoverCheckoutObserver(tabId, allowance) {
  const d = { checkoutTabIdPresent: Number.isInteger(tabId), checkoutFrameId: 0,
    checkoutHostPermissionMatch: null, checkoutInjectionRequested: false,
    checkoutInjectionApiSucceeded: null, checkoutInjectionErrorCode: null,
    checkoutScriptBootstrapAck: false, checkoutScriptBootstrapErrorCode: null,
    checkoutContentScriptLoaded: false, checkoutContentScriptPortConnected: false,
    // This is the runtime message channel; there is no persistent content Port.
    checkoutTransport: 'RUNTIME_MESSAGE', recoveryBlockedReason: null }
  let documentId
  const ack = async () => {
    const connected = await checkoutObserverHello(tabId, documentId)
    d.checkoutScriptBootstrapAck = connected
    d.checkoutContentScriptLoaded = connected
    d.checkoutContentScriptPortConnected = connected
    d.checkoutScriptBootstrapErrorCode = connected ? null : 'CONTENT_SCRIPT_NO_RESPONSE'
    return connected
  }
  if (!d.checkoutTabIdPresent || activeJob) { d.recoveryBlockedReason = 'ACTIVE_JOB_OR_INVALID_TAB'; return d }
  try {
    d.checkoutHostPermissionMatch = await boundedBindStep(checkoutChromeRead(cb =>
      chrome.permissions.contains({ origins: [SHOP_APP_HOST_PATTERN] }, cb)), 'CHECKOUT_HOST_PERMISSION') === true
    if (!d.checkoutHostPermissionMatch) { d.recoveryBlockedReason = 'HOST_PERMISSION_DENIED'; return d }
    const frame = await boundedBindStep(checkoutChromeRead(cb =>
      chrome.webNavigation.getFrame({ tabId, frameId: 0 }, cb)), 'CHECKOUT_FRAME')
    if (!frame || !frame.documentId || frame.parentFrameId !== -1 ||
        new URL(frame.url).origin !== 'https://shop.app') {
      d.recoveryBlockedReason = 'FRAME_UNAVAILABLE'; return d
    }
    documentId = frame.documentId
    d.documentId = documentId // volatile routing only; durable projection excludes it
    if (await ack()) return d
    // Older static scripts may answer the existing probe but not the new HELLO.
    // Preserve compatibility without injecting a second observer into a healthy script.
    const existing = await probeBindingCapability(tabId, documentId)
    if (existing.responder) {
      d.checkoutContentScriptLoaded = true
      d.checkoutContentScriptPortConnected = true
      d.checkoutScriptBootstrapAck = null
      d.checkoutScriptBootstrapErrorCode = null
      d.existingProbe = existing
      return d
    }
    const key = `${tabId}:${frame.documentId}`
    if (activeJob || allowance.used || Date.now() < (checkoutObserverAttempts.get(key) ?? 0)) {
      d.recoveryBlockedReason = activeJob ? 'ACTIVE_JOB' : 'OBSERVER_RECOVERY_BACKOFF'; return d
    }
    allowance.used = true
    // One attempt per document per conservative window; no timer or poller.
    checkoutObserverAttempts.set(key, Date.now() + CHECKOUT_OBSERVER_RETRY_MS)
    while (checkoutObserverAttempts.size > MAX_BIND_DISCOVERY_TABS) checkoutObserverAttempts.delete(checkoutObserverAttempts.keys().next().value)
    d.checkoutInjectionRequested = true
    try {
      // documentIds prevents a navigation race from injecting into a different frame/page.
      const result = await boundedBindStep(chrome.scripting.executeScript({
        target: { tabId, documentIds: [frame.documentId] }, world: 'ISOLATED',
        files: ['checkout-observation.js'],
      }), 'CHECKOUT_OBSERVER_INJECTION', BIND_CONTENT_RESPONSE_TIMEOUT_MS)
      d.checkoutInjectionApiSucceeded = Array.isArray(result) && result.length === 1 &&
        result[0].frameId === 0 && result[0].documentId === frame.documentId
      if (!d.checkoutInjectionApiSucceeded) d.checkoutInjectionErrorCode = 'INJECTION_FRAME_MISMATCH'
    } catch (error) {
      d.checkoutInjectionApiSucceeded = false
      d.checkoutInjectionErrorCode = checkoutRecoveryError(error)
    }
    // Read back even an ambiguous API result. Never reinject blindly.
    if (!activeJob) await ack()
  } catch (error) { d.recoveryBlockedReason = checkoutRecoveryError(error) }
  return d
}
async function observeRecoverableCheckout(tabId, allowance) {
  const recovery = await recoverCheckoutObserver(tabId, allowance)
  if (recovery.existingProbe && !activeJob) return { ...recovery.existingProbe, recovery }
  if (!recovery.checkoutScriptBootstrapAck || activeJob ||
      (recovery.checkoutInjectionRequested && recovery.checkoutInjectionApiSucceeded !== true)) {
    return { id: tabId, responded: false, responder: false, eligible: false, recovery }
  }
  return { ...await probeBindingCapability(tabId, recovery.documentId), recovery }
}

function safeEligibilityResponse(value) {
  const fields = ["eligible", "checkoutPageDetected",
    "shipToMarker", "shippingMarker", "subtotalMarker", "totalMarker",
    "payNowMarker"]
  if (!value || typeof value !== "object" ||
      value.contractVersion !== BIND_ELIGIBILITY_CONTRACT ||
      value.checkoutHostClassification !== "SHOP_PAY_CHECKOUT_HOST" ||
      fields.some((field) => typeof value[field] !== "boolean")) return null
  return Object.freeze({ contractVersion: value.contractVersion,
    checkoutHostClassification: value.checkoutHostClassification,
    diagnosticVersion: value.diagnosticVersion === "LUNA_CHECKOUT_OBSERVATION_V1"
      ? value.diagnosticVersion : null,
    ...Object.fromEntries(fields.map((field) => [field, value[field]])) })
}

async function probeBindingCapability(tabId, documentId) {
  try {
    const response = await boundedBindStep(sendTabMessage(tabId, {
      type: BIND_ELIGIBILITY_PROBE,
      contractVersion: BIND_ELIGIBILITY_CONTRACT,
    }, documentId), "BIND_CHECKOUT_TAB_ELIGIBILITY", BIND_TOP_FRAME_TIMEOUT_MS)
    const safe = safeEligibilityResponse(response)
    return { id: tabId, responded: response !== undefined,
      responder: Boolean(safe), probeError: !safe, observation: safe,
      eligible: Boolean(safe) && safe.eligible && safe.checkoutPageDetected &&
      safe.checkoutHostClassification === "SHOP_PAY_CHECKOUT_HOST" &&
      safe.shipToMarker && safe.shippingMarker && safe.subtotalMarker &&
      safe.totalMarker && safe.payNowMarker }
  } catch {
    return { id: tabId, responded: false, responder: false,
      probeError: true, eligible: false }
  }
}

function checkoutObservationV1(tabFound, probe) {
  const safe = probe?.observation
  const expectedMarkers = ["shipToMarker", "shippingMarker", "subtotalMarker",
    "totalMarker", "payNowMarker"]
  const responded = probe?.responded === true
  const evaluated = Boolean(safe)
  const observedMarkers = evaluated ? expectedMarkers.filter(key => safe[key]) : []
  const missingMarkers = evaluated ? expectedMarkers.filter(key => !safe[key]) : []
  const ready = probe?.eligible === true
  const pageDetected = evaluated && safe.checkoutPageDetected
  return {
    version: "LUNA_CHECKOUT_OBSERVATION_V1", checkoutTabFound: tabFound,
    checkoutHostMatch: tabFound, // queryTabs is restricted to https://shop.app/*
    checkoutInjectionRequested: false, checkoutInjectionApiSucceeded: null,
    checkoutScriptBootstrapAck: null, contentScriptAuthority: "STATIC_OR_READ_ONLY_RECOVERY",
    ...Object.fromEntries(Object.entries(probe?.recovery ?? {})
      .filter(([key]) => key !== 'documentId' && key !== 'existingProbe')),
    checkoutContentScriptResponded: responded,
    checkoutPageDetected: Boolean(pageDetected), shopPayMarkersEvaluated: evaluated,
    shopPayRequiredMarkersReady: evaluated && missingMarkers.length === 0,
    checkoutDomReady: ready, expectedMarkers, observedMarkers, missingMarkers,
    markerContractDrift: null, productIdentityStatus: "NOT_EVALUATED",
    quantityIdentityStatus: "NOT_EVALUATED",
    checkoutNotReadyReason: !tabFound ? "NO_CHECKOUT_TAB"
      : probe?.recovery?.recoveryBlockedReason ?? (probe?.recovery?.checkoutInjectionErrorCode
        ? "INJECTION_FAILED" : !responded ? "CONTENT_SCRIPT_NO_RESPONSE"
      : !evaluated ? "CONTENT_SCRIPT_RESPONSE_INVALID"
      : !pageDetected ? "CHECKOUT_PAGE_NOT_DETECTED"
      : !ready ? "REQUIRED_MARKERS_MISSING" : "READY"),
  }
}

// Independent read-only capability observation. No cart, navigation, fetch,
// binding mutation or job discovery. Existing worker events drive transitions.
let captureCapabilityProbeInFlight = false
async function reportCaptureCapability() {
  if (!sellerPort || captureCapabilityProbeInFlight || activeJob) return
  captureCapabilityProbeInFlight = true
  const responsePort = sellerPort
  try {
    const binding = await readDestinationBinding()
    // Enumerate existing Shop Pay tabs once, even when a tab event triggered
    // the observation. A non-ready tab must not hide another ready checkout.
    const candidates = (await queryTabs({ url: ["https://shop.app/*"] }))
      .slice(0, MAX_BIND_DISCOVERY_TABS)
    let observation = null
    const recoveryAllowance = { used: false }
    for (const tab of candidates) {
      const probe = await observeRecoverableCheckout(tab.id, recoveryAllowance)
      // Prefer an actual structured response over silence; stop at readiness.
      if (!observation || probe.responder || probe.eligible) observation = probe
      if (probe.eligible) break
    }
    const checkout = checkoutObservationV1(candidates.length > 0, observation)
    const checkoutDomReady = checkout.checkoutDomReady
    if (sellerPort === responsePort) responsePort.postMessage({
      type: "LUNA_CAPTURE_CAPABILITY_STATE_V1", probe: {
        contract: "LUNA_CAPTURE_READ_ONLY_PROBE_V1",
        observedAt: new Date().toISOString(),
        canonicalBindingPresent: Boolean(binding), checkoutDomReady,
        captureAvailable: Boolean(binding) && checkoutDomReady,
        checkoutObservation: checkout,
      },
    })
  } catch {
    if (sellerPort === responsePort) responsePort.postMessage({
      type: "LUNA_CAPTURE_CAPABILITY_STATE_V1", probe: {
        contract: "LUNA_CAPTURE_READ_ONLY_PROBE_V1", observedAt: new Date().toISOString(),
        captureAvailable: false, canonicalBindingPresent: false, checkoutDomReady: false,
        checkoutObservation: { ...checkoutObservationV1(false, null),
          checkoutNotReadyReason: "PROBE_RUNTIME_FAILURE" },
      },
    })
  } finally { captureCapabilityProbeInFlight = false }
}

async function requestDestinationOperationFromTab(tabId, message) {
  try {
    return await boundedBindStep(sendTabMessage(tabId, message),
      "BIND_CONTENT_SCRIPT_RESPONSE", BIND_CONTENT_RESPONSE_TIMEOUT_MS)
  } catch (error) {
    if (error instanceof Error && new Set([
      "CHECKOUT_CONTENT_SCRIPT_NOT_AVAILABLE",
      "BIND_TIMEOUT:BIND_CONTENT_SCRIPT_RESPONSE",
    ]).has(error.message)) {
      throw new Error("BIND_CONTENT_SCRIPT_NOT_RESPONDING")
    }
    throw error
  }
}

function safeBindingExecutionResponse(value, validating) {
  const markers = value?.safeMarkerBooleans
  const markerFields = ["shipTo", "shipping", "subtotal", "total", "payNow"]
  if (!value || typeof value !== "object" ||
      value.contractVersion !== BIND_EXECUTION_CONTRACT ||
      value.success !== true || value.fingerprintVersion !==
        DESTINATION_FINGERPRINT_VERSION || value.countryClass !== "US" ||
      !/^sha256:[0-9a-f]{64}$/.test(value.fingerprint ?? "") ||
      !markers || markerFields.some((field) => markers[field] !== true) ||
      (validating && value.canonicalDestinationMatch !== true)) return null
  return Object.freeze({ fingerprint: value.fingerprint,
    fingerprintVersion: value.fingerprintVersion, countryClass: "US",
    canonicalDestinationMatch: value.canonicalDestinationMatch === true })
}

async function discoverCanonicalBindingCheckoutTab() {
  emitRuntimeTrace("BIND_SHOP_APP_TAB_DISCOVERY_STARTED")
  emitRuntimeTrace("BIND_EXISTING_CHECKOUT_SEARCH_STARTED")
  const discovery = await boundedBindStep(queryAccessibleTabIds(),
    "BIND_SHOP_APP_TAB_DISCOVERY_STARTED")
  const checkoutTabs = discovery.tabs
  const probedTabs = await Promise.all(checkoutTabs.map(({ id }) =>
    probeBindingCapability(id)))
  const responderTabs = probedTabs.filter((tab) => tab.responder)
  const eligibleTabs = probedTabs.filter((tab) => tab.eligible)
  const responseTabs = probedTabs.filter((tab) => tab.responded)
  const errorTabs = probedTabs.filter((tab) => tab.probeError)
  emitRuntimeTrace("BIND_SHOP_APP_TAB_DISCOVERY_RESULT", true, "NONE", {
    tabsQueryTotalCount: discovery.totalCount,
    tabsEnumeratedCount: checkoutTabs.length,
    shopAppProbedCount: probedTabs.length,
    contentScriptResponderCount: responderTabs.length,
    eligibleCheckoutCount: eligibleTabs.length,
    probeAttemptCount: probedTabs.length,
    probeResponseCount: responseTabs.length,
    eligibleResponseCount: eligibleTabs.length,
    probeErrorCount: errorTabs.length,
    bindCheckoutDiscoveryValidCount: eligibleTabs.length,
  })
  if (!eligibleTabs.length) {
    return null
  }
  if (eligibleTabs.length > 1) {
    throw new Error("MULTIPLE_BIND_CHECKOUT_TABS_FOUND")
  }
  const [{ id: checkoutTabId }] = eligibleTabs
  emitRuntimeTrace("BIND_SHOP_APP_TAB_SELECTED")
  return checkoutTabId
}

async function bindCanonicalDestination(existingBinding, checkoutTabId) {
  if (!Number.isInteger(checkoutTabId)) {
    throw new Error("BIND_CHECKOUT_TAB_SELECTION_INVALID")
  }
  const message = { type: BIND_CANONICAL_DESTINATION_EXECUTE,
    contractVersion: BIND_EXECUTION_CONTRACT,
    operation: existingBinding ? "VALIDATE" : "BIND",
    ...(existingBinding ? { binding: existingBinding } : {}) }
  emitRuntimeTrace("BIND_TOP_FRAME_EXECUTION_STARTED")
  const response = await requestDestinationOperationFromTab(
    checkoutTabId, message)
  if (response?.success !== true) {
    throw new Error(safeRuntimeReason(response?.error ??
      "BIND_EXECUTE_SCRIPT_RESULT_NOT_RETURNED"))
  }
  const safeExecution = safeBindingExecutionResponse(response,
    Boolean(existingBinding))
  if (!safeExecution) throw new Error("BIND_CHECKOUT_MARKERS_INVALID")
  emitRuntimeTrace("BIND_CHECKOUT_MARKERS_VERIFIED")
  emitRuntimeTrace("BIND_SHIP_TO_DETECTED")
  const candidate = existingBinding ?? safeDestinationCandidate({
    canonicalDestinationFingerprint: safeExecution.fingerprint,
    fingerprintVersion: safeExecution.fingerprintVersion,
    countryClass: safeExecution.countryClass,
  })
  if (!candidate) throw new Error("BIND_SHIP_TO_NOT_FOUND")
  emitRuntimeTrace("BIND_SHIP_TO_AVAILABLE")
  emitRuntimeTrace("CANONICAL_FINGERPRINT_COMPUTED")
  const binding = existingBinding ?? Object.freeze({ ...candidate,
    boundAt: new Date().toISOString() })
  if (!existingBinding) {
    emitRuntimeTrace("CANONICAL_FINGERPRINT_WRITE_STARTED")
    await boundedBindStep(writeDestinationBinding(binding),
      "CANONICAL_FINGERPRINT_WRITE_STARTED")
    emitRuntimeTrace("CANONICAL_FINGERPRINT_WRITE_COMPLETE")
  }
  const readback = await boundedBindStep(readDestinationBinding(),
    "CANONICAL_FINGERPRINT_READBACK_VERIFIED")
  if (!readback ||
      readback.canonicalDestinationFingerprint !==
        binding.canonicalDestinationFingerprint) {
    throw new Error("BIND_STORAGE_READBACK_MISMATCH")
  }
  emitRuntimeTrace("CANONICAL_FINGERPRINT_READBACK_VERIFIED")
  emitRuntimeTrace("CANONICAL_DESTINATION_MATCH")
  emitRuntimeTrace("CANONICAL_BIND_COMPLETED")
  return { type: DESTINATION_BINDING_RESULT, success: true,
    canonicalDestinationBound: true, canonicalDestinationMatch: true,
    canonicalUsProfileFound: true, shippingAddressAccepted: true,
    operation: existingBinding ? "VALIDATE_CANONICAL_DESTINATION"
      : "BIND_CANONICAL_DESTINATION" }
}

async function bootstrapCanonicalDestinationCheckout(bootstrapJob) {
  const invalidReason = jobValidationReason(bootstrapJob)
  if (invalidReason) throw new Error("BIND_BOOTSTRAP_JOB_INVALID")
  if (activeJob) throw new Error("BIND_BOOTSTRAP_ACTIVE_JOB_CONFLICT")
  canonicalBindBootstrapActive = true
  canonicalBindBootstrapTraceStates = new Set()
  canonicalBindBootstrapAttempted = true
  const checkoutReady = waitForCanonicalBindCheckout()
  try {
    const startJobPromise = startJob(bootstrapJob, false, true)
    emitRuntimeTrace("BIND_START_JOB_INVOKED", true, "NONE", {
      bindCheckoutBootstrapRequired: true,
      bindCheckoutBootstrapAttempted: true,
      bindStartJobInvoked: true,
    })
    await startJobPromise
    emitBindBootstrapTraceOnce("BIND_BOOTSTRAP_PRODUCT_OPENED")
    await checkoutReady
  } catch (error) {
    settleCanonicalBindCheckout(error instanceof Error ? error
      : new Error("BIND_CHECKOUT_BOOTSTRAP_FAILED"))
    await checkoutReady.catch(() => {})
    throw error
  }
  const checkoutTabId = await discoverCanonicalBindingCheckoutTab()
  if (!Number.isInteger(checkoutTabId)) {
    if (!canonicalBindBootstrapAttempted) {
      throw new Error("BIND_CHECKOUT_BOOTSTRAP_INVARIANT_VIOLATION")
    }
    throw new Error("BIND_CHECKOUT_TAB_NOT_FOUND")
  }
  emitBindBootstrapTraceOnce("BIND_BOOTSTRAP_CHECKOUT_DETECTED")
  return checkoutTabId
}

async function handleCanonicalDestinationBinding(port, bootstrapJob) {
  if (canonicalBindInFlight) {
    try {
      port.postMessage({ type: DESTINATION_BINDING_RESULT, success: false,
        canonicalDestinationBound: false, canonicalDestinationMatch: false,
        error: "BIND_ALREADY_IN_PROGRESS" })
    } catch { /* The caller bridge is already unavailable. */ }
    return
  }
  canonicalBindInFlight = true
  canonicalBindBootstrapAttempted = false
  let existingBinding = null
  let bindingResponse = null
  try {
    await beginRuntimeTrace(crypto.randomUUID(), null)
    emitRuntimeTrace("CANONICAL_BIND_REQUESTED")
    emitRuntimeTrace("BIND_REQUEST_ACCEPTED")
    existingBinding = await boundedBindStep(readDestinationBinding(),
      "CANONICAL_BIND_REQUESTED")
    bindingResponse = await bindOperatorCanonicalDestination(existingBinding,
      bootstrapJob)
  } catch (error) {
    emitRuntimeTrace("FAIL", false, error instanceof Error ? error.message
      : "CANONICAL_US_PROFILE_VALIDATION_UNAVAILABLE")
    try {
      port.postMessage({ type: DESTINATION_BINDING_RESULT, success: false,
        canonicalDestinationBound: Boolean(existingBinding),
        canonicalDestinationMatch: false,
        error: safeRuntimeReason(error instanceof Error ? error.message
          : "CANONICAL_US_PROFILE_VALIDATION_UNAVAILABLE") })
    } catch {
      emitRuntimeTrace("FAIL", false, "BIND_ACK_FAILED")
    }
  } finally {
    if (bindingResponse) finalizeCanonicalBindRuntime(false)
    canonicalBindInFlight = false
  }
  if (!bindingResponse) return
  emitRuntimeTrace("PASS")
  try {
    port.postMessage(bindingResponse)
  } catch {
    emitRuntimeTrace("FAIL", false, "BIND_ACK_FAILED")
  } finally {
    activeRuntimeTrace = null
  }
}

function emitProgress(state, details = {}) {
  if (!sellerPort || !activeJob) return
  const rank = CHECKOUT_STATE_RANK.get(state) ?? 0
  if (rank && (rank < lastCheckoutStateRank ||
      (rank === lastCheckoutStateRank && state !== lastCheckoutState))) return
  if (rank) {
    lastCheckoutStateRank = rank
    lastCheckoutState = state
  }
  lastRuntimeState = state
  traceProgress(state, details)
  const markerDetails = {}
  for (const field of ["shopPayMarkerOrderSummary", "shopPayMarkerProduct",
    "shopPayMarkerQuantity", "shopPayMarkerShipTo", "shopPayMarkerShipping",
    "shopPayMarkerSubtotal", "shopPayMarkerShippingAmount",
    "shopPayMarkerTotal", "shopPayMarkerShippingMethod",
    "shopPayMarkerPayment", "shopPayMarkerPayNow", "subtotalLabelFound",
    "subtotalAmountCandidateFound", "subtotalCurrencyFound", "subtotalParsed",
    "shippingLabelFound", "shippingAmountCandidateFound",
    "shippingCurrencyFound", "shippingParsed", "totalLabelFound",
    "totalAmountCandidateFound", "totalCurrencyFound", "totalParsed"]) {
    if (typeof details[field] === "boolean") markerDetails[field] = details[field]
  }
  sellerPort.postMessage({ type: JOB_PROGRESS, state,
    candidateId: activeJob.identity.candidateId,
    ...(Number.isFinite(details.cartSubtotalUsd) &&
      details.cartSubtotalUsd >= 0 && details.cartSubtotalUsd <= 100_000
      ? { cartSubtotalUsd: Math.round(details.cartSubtotalUsd * 100) / 100 }
      : {}),
    ...(traceMoney(details.subtotalUsd) !== null
      ? { subtotalUsd: traceMoney(details.subtotalUsd) } : {}),
    ...(traceMoney(details.shippingUsd) !== null
      ? { shippingUsd: traceMoney(details.shippingUsd) } : {}),
    ...(traceMoney(details.totalUsd) !== null
      ? { totalUsd: traceMoney(details.totalUsd) } : {}),
    ...(new Set(["LUNA_STOREFRONT_CHECKOUT_HOST", "LUNA_ACCOUNT_HOST",
      "SHOP_PAY_CHECKOUT_HOST",
      "UNSUPPORTED_CHECKOUT_HOST"]).has(details.checkoutHostClassification)
      ? { checkoutHostClassification: details.checkoutHostClassification } : {}),
    ...(safeNavigationIdentity(`https://${details.checkoutNavigationHost}`)
      ? { checkoutNavigationHost: details.checkoutNavigationHost } : {}),
    ...(safeNavigationIdentity(details.checkoutNavigationOrigin)
      ? { checkoutNavigationOrigin: details.checkoutNavigationOrigin } : {}),
    ...(typeof details.checkoutHostPermissionMatch === "boolean"
      ? { checkoutHostPermissionMatch: details.checkoutHostPermissionMatch } : {}),
    ...(Number.isInteger(details.checkoutInjectionFrameId) &&
      details.checkoutInjectionFrameId === 0
      ? { checkoutInjectionFrameId: details.checkoutInjectionFrameId } : {}),
    ...(typeof details.checkoutScriptBootstrapAck === "boolean"
      ? { checkoutScriptBootstrapAck: details.checkoutScriptBootstrapAck } : {}),
    ...(new Set(["PENDING", "INJECTION_API_ERROR", "WRONG_FRAME_TARGET",
      "CHECKOUT_CONTENT_SCRIPT_BOOTSTRAP_NOT_ACKNOWLEDGED"])
      .has(details.checkoutScriptBootstrapErrorCode)
      ? { checkoutScriptBootstrapErrorCode:
          details.checkoutScriptBootstrapErrorCode } : {}),
    ...(new Set(["NORMAL_CHECKOUT_WITH_SHIPPING", "UNKNOWN_CHECKOUT_PAGE"])
      .has(details.checkoutPageClassification)
      ? { checkoutPageClassification: details.checkoutPageClassification } : {}),
    ...(new Set(["EXPLICIT_CHALLENGE_UI", "EXPLICIT_LOGIN_REQUIRED",
      "SESSION_EXPIRED_UI", "NO_EXPLICIT_AUTH_REQUIREMENT"])
      .has(details.authSignal) ? { authSignal: details.authSignal } : {}),
    ...(details.authSignalSource === "FIXED_HOST_PATH_AND_VISIBLE_DOM"
      ? { authSignalSource: details.authSignalSource } : {}),
    ...markerDetails })
}

function postExactDispatchReceived(deliveryPort, exact, traceId,
  portGeneration) {
  exactDispatchMessageReceivedCandidateId = exact.identity.candidateId
  deliveryPort?.postMessage({ type: EXTENSION_DISPATCH_RECEIVED,
    candidateId: exact.identity.candidateId,
    traceId,
    portGeneration,
    backgroundOnMessageReached: true,
    messageTypeAccepted: true,
    messageCandidateId: exact.identity.candidateId,
    backgroundActiveJobCandidateId: activeJob?.identity?.candidateId ?? "NONE",
  })
}

async function startJob(job, productionAutoClaim = false,
  preserveRuntimeTrace = false, requireDurableDispatchAck = false,
  preDispatchTrace = null, deliveryPort = sellerPort,
  portGeneration = null) {
  const invalidReason = jobValidationReason(job)
  if (invalidReason) throw new Error(invalidReason)
  await terminalCleanupChain
  const exact = safeJob(job)
  const url = exact && exactLunaUrl(exact.identity.canonicalProductUrl)
  if (!exact || !url) throw new Error("JOB_IDENTITY_MISMATCH:identity.canonicalProductUrl")
  const exactPreDispatchTrace = requireDurableDispatchAck === true
    ? await adoptExactPreDispatchRuntimeTrace(preDispatchTrace, exact) : null
  if (activeJob) {
    if (sameJob(activeJob, exact)) {
      if (requireDurableDispatchAck !== true) return false
      if (!exactPreDispatchTrace ||
          activeRuntimeTrace?.traceId !== exactPreDispatchTrace.traceId ||
          activeRuntimeTrace?.candidateId !== exact.identity.candidateId) {
        throw new Error("LUNA_EXACT_DISPATCH_TRACE_IDENTITY_MISMATCH")
      }
      for (const event of activeRuntimeTrace.events) {
        deliveryPort?.postMessage({ type: RUNTIME_TRACE_EVENT, event })
      }
      postExactDispatchReceived(deliveryPort, exact,
        exactPreDispatchTrace.traceId, portGeneration)
      return false
    }
    if (requireDurableDispatchAck !== true) {
      throw new Error("LUNA_SHIPPING_JOB_ALREADY_RUNNING")
    }
    clearActiveJob()
  }
  activeJob = exact
  armActiveJobTimeout()
  if (exactPreDispatchTrace) {
    activeRuntimeTrace = exactPreDispatchTrace
    for (const event of activeRuntimeTrace.events) {
      deliveryPort?.postMessage({ type: RUNTIME_TRACE_EVENT, event })
    }
  }
  if (requireDurableDispatchAck === true) {
    postExactDispatchReceived(deliveryPort, exact,
      exactPreDispatchTrace?.traceId ?? null, portGeneration)
  }
  initializeCheckoutNavigationObserver(exact)
  if (!preserveRuntimeTrace && !exactPreDispatchTrace) {
    await beginRuntimeTrace(exact.captureSessionId, exact.identity.candidateId)
  }
  if (productionAutoClaim === true) {
    emitRuntimeTrace("PRODUCTION_OBSERVER_REARMED")
    emitRuntimeTrace("PRODUCTION_WORKER_READY")
    emitRuntimeTrace("INITIAL_AUTO_CLAIM_STARTED")
    emitRuntimeTrace("ELIGIBLE_JOB_FOUND")
    emitRuntimeTrace("PRODUCTION_JOB_CLAIMED")
    emitRuntimeTrace("PRODUCTION_JOB_DISPATCHED")
  }
  emitRuntimeTrace("BRIDGE_CONNECTED")
  emitRuntimeTrace("JOB_DISPATCHED")
  activeJobPhase = "PRODUCT_PAGE"
  originalCartSnapshot = null
  cartSubtotalUsd = null
  checkoutNavigationArmed = false
  checkoutNavigationTriggered = false
  checkoutInjectionStarted = false
  checkoutBootstrapAckReceived = false
  checkoutBootstrapAckEmitted = false
  if (checkoutBootstrapAckTimer) clearTimeout(checkoutBootstrapAckTimer)
  checkoutBootstrapAckTimer = null
  lastCheckoutStateRank = 0
  lastCheckoutState = null
  lastRuntimeState = "CANARY_DISPATCHED"
  url.hash = `seller-os-luna-shipping-v1=${encodeJob(exact)}`
  if (requireDurableDispatchAck === true) {
    pendingExactDispatch = Object.freeze({
      candidateId: exact.identity.candidateId,
      captureSessionId: exact.captureSessionId,
      traceId: activeRuntimeTrace?.traceId ?? null,
      url: url.toString(),
    })
    return true
  }
  await navigateActiveJob(url.toString())
  return true
}

async function navigateActiveJob(url) {
  if (activeTabId === null) {
    const tab = await chrome.tabs.create({ url, active: true })
    if (!Number.isInteger(tab.id)) throw new Error("LUNA_SHIPPING_TAB_UNAVAILABLE")
    activeTabId = tab.id
    await registerOwnedRunTab(tab.id, activeJob?.captureSessionId ?? "UNKNOWN")
  } else {
    await chrome.tabs.update(activeTabId, { url, active: true })
    if (activeJob && ownedRunTabs.has(activeTabId)) {
      await registerOwnedRunTab(activeTabId, activeJob.captureSessionId)
    }
  }
}

function failActiveJob(error) {
  if (!activeJob) return
  emitRuntimeTrace("FAIL", false, safeRuntimeReason(error))
  try {
    sellerPort?.postMessage({ type: JOB_RESULT, success: false,
      error: safeRuntimeReason(error), lastRuntimeState,
      capture: { candidateId: activeJob.identity.candidateId } })
  } catch { /* Terminal cleanup must outlive a disconnected UI port. */ }
  void terminateActiveJob(error)
}

function failBindingBootstrapOrActiveJob(error) {
  if (canonicalBindBootstrapActive) {
    settleCanonicalBindCheckout(new Error(safeRuntimeReason(error)))
    return
  }
  failActiveJob(error)
}

function failObservedDisallowedCheckout(observed, allowed) {
  if (!observed || allowed || !checkoutNavigationObservation?.observed ||
      checkoutNavigationObservation.origin !== observed.origin) return false
  failBindingBootstrapOrActiveJob("REAL_CHECKOUT_HOST_NOT_ALLOWLISTED")
  return true
}

function emitCheckoutBootstrapAck() {
  if (!activeJob || !checkoutInjectionStarted ||
      !checkoutBootstrapAckReceived || checkoutBootstrapAckEmitted) return
  checkoutBootstrapAckEmitted = true
  if (checkoutBootstrapAckTimer) clearTimeout(checkoutBootstrapAckTimer)
  checkoutBootstrapAckTimer = null
  emitProgress("CHECKOUT_SCRIPT_BOOTSTRAP_ACK", {
    checkoutInjectionFrameId: 0, checkoutScriptBootstrapAck: true,
  })
  emitProgress("CHECKOUT_CONTENT_SCRIPT_LOADED", {
    checkoutInjectionFrameId: 0, checkoutScriptBootstrapAck: true,
  })
}

function observeCheckoutNavigation(details, inject) {
  if (!activeJob || activeJobPhase !== CHECKOUT_PHASE ||
      !checkoutNavigationArmed || !checkoutNavigationTriggered ||
      !Array.isArray(originalCartSnapshot) ||
      !Number.isFinite(cartSubtotalUsd) ||
      details?.tabId !== activeTabId || details?.frameId !== 0) return
  if (!checkoutNavigationObservation?.armed ||
      checkoutNavigationObservation.captureSessionId !==
        activeJob.captureSessionId) return
  if (isPreNavigationCartDocument(details.url)) return
  const observed = safeNavigationIdentity(details.url)
  if (!observed) return
  const allowed = allowedCheckoutNavigation(details.url)
  const firstObservation = !checkoutNavigationObservation.observed
  if (firstObservation) {
    checkoutNavigationObservation.observed = true
    checkoutNavigationObservation.tabId = details.tabId
    checkoutNavigationObservation.host = observed.host
    checkoutNavigationObservation.origin = observed.origin
    if (checkoutNavigationObservationTimer) {
      clearTimeout(checkoutNavigationObservationTimer)
      checkoutNavigationObservationTimer = null
    }
  } else if (checkoutNavigationObservation.tabId !== details.tabId) {
    return
  } else if (checkoutNavigationObservation.host !== observed.host) {
    checkoutNavigationObservation.host = observed.host
    checkoutNavigationObservation.origin = observed.origin
    failObservedDisallowedCheckout(observed, allowed)
    return
  }
  if (!inject && !checkoutBootstrapAckReceived) {
    lastCheckoutStateRank = CHECKOUT_STATE_RANK.get(CHECKOUT_PHASE) ?? 0
    lastCheckoutState = CHECKOUT_PHASE
  }
  if (firstObservation) {
    emitProgress("CHECKOUT_NAVIGATION_OBSERVED", {
      checkoutNavigationHost: observed.host,
      checkoutNavigationOrigin: observed.origin,
      checkoutHostPermissionMatch: Boolean(allowed),
    })
    emitBindBootstrapTraceOnce("BIND_BOOTSTRAP_CHECKOUT_NAVIGATION_OBSERVED")
  }
  if (!allowed) {
    failObservedDisallowedCheckout(observed, allowed)
    return
  }
  emitProgress("CHECKOUT_HOST_ALLOWED", {
    checkoutNavigationHost: allowed.host,
    checkoutNavigationOrigin: allowed.origin,
    checkoutHostPermissionMatch: true,
  })
  if (!inject && !checkoutBootstrapAckReceived) {
    checkoutInjectionStarted = false
    checkoutBootstrapAckReceived = false
    checkoutBootstrapAckEmitted = false
    if (checkoutBootstrapAckTimer) clearTimeout(checkoutBootstrapAckTimer)
    checkoutBootstrapAckTimer = null
    return
  }
  if (checkoutInjectionStarted) return
  checkoutInjectionStarted = true
  emitProgress("CHECKOUT_INJECTION_REQUESTED", {
    checkoutInjectionFrameId: 0, checkoutScriptBootstrapAck: false,
    checkoutScriptBootstrapErrorCode: "PENDING",
  })
  if (checkoutBootstrapAckReceived) {
    emitCheckoutBootstrapAck()
    return
  }
  checkoutBootstrapAckTimer = setTimeout(() => {
    checkoutBootstrapAckTimer = null
    failBindingBootstrapOrActiveJob(
      "CHECKOUT_CONTENT_SCRIPT_BOOTSTRAP_NOT_ACKNOWLEDGED")
  }, CHECKOUT_BOOTSTRAP_ACK_TIMEOUT_MS)
}

async function ensureShippingWorkerControlPage() {
  if (chrome.runtime.id !== EXACT_EXTENSION_ID) return false
  const workerControlUrl = `${CONTROL_PAGE}?bridgeOnly=1&workerVersion=${
    encodeURIComponent(EXTENSION_BUILD_VERSION)}`
  let tabs
  try {
    tabs = await chrome.tabs.query({
      url: `${SELLER_OS_ORIGIN}/admin/ebay/luna-shipping-capture*`,
    })
  } catch { return false }
  const existingWorkerTab = tabs.find((tab) => {
    try {
      return new URL(tab.url ?? "").searchParams.get("bridgeOnly") === "1"
    } catch { return false }
  })
  if (existingWorkerTab) {
    try {
      const currentWorkerVersion = new URL(existingWorkerTab.url ?? "")
        .searchParams.get("workerVersion")
      if (currentWorkerVersion === EXTENSION_BUILD_VERSION) return true
      if (!Number.isInteger(existingWorkerTab.id)) return false
      await chrome.tabs.update(existingWorkerTab.id, {
        url: workerControlUrl, active: false,
      })
      return true
    } catch { return false }
  }
  try {
    await chrome.tabs.create({
      url: workerControlUrl, active: false,
    })
    return true
  } catch { return false }
}

function scheduleShippingWorkerRecovery() {
  chrome.alarms?.create?.(WORKER_CONTROL_ALARM, { periodInMinutes: 2 })
  void ensureShippingWorkerControlPage()
}

chrome.runtime.onInstalled?.addListener?.(scheduleShippingWorkerRecovery)
chrome.runtime.onStartup?.addListener?.(scheduleShippingWorkerRecovery)
chrome.alarms?.onAlarm?.addListener?.((alarm) => {
  if (alarm.name === WORKER_CONTROL_ALARM) {
    void ensureShippingWorkerControlPage()
  } else if (alarm.name === JOB_TIMEOUT_ALARM && activeJob) {
    failActiveJob("LUNA_SHIPPING_JOB_TIMEOUT")
  }
})

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message?.type !== EXTENSION_PING || !safeSellerSender(sender) ||
      chrome.runtime.id !== EXACT_EXTENSION_ID ||
      !effectiveShopAppContract()) return false
  sendResponse({
    type: EXTENSION_READY,
    extensionId: EXACT_EXTENSION_ID,
    extensionVersion: chrome.runtime.getManifest().version,
    extensionBuildVersion: EXTENSION_BUILD_VERSION,
    shopAppManifestPermission: true,
    shopAppContentScriptMatch: true,
    shopAppRuntimeAllowlist: true,
    shopAppCheckoutHostClassification: true,
    unicodeProductHandleSupport: true,
    sellerOsOriginValidated: true,
  })
  return false
})

chrome.runtime.onConnectExternal.addListener((port) => {
  if (port.name !== PORT_NAME || !safeSellerSender(port.sender) || sellerPort) {
    port.disconnect()
    return
  }
  sellerPort = port
  let acceptedPortGeneration = null
  for (const event of activeRuntimeTrace?.events ?? []) {
    port.postMessage({ type: RUNTIME_TRACE_EVENT, event })
  }
  port.onMessage.addListener((message) => {
    if (sellerPort !== port) return
    if (message?.type === PORT_HANDSHAKE) {
      if (!Number.isInteger(message.portGeneration) ||
          message.portGeneration < 1 || message.portGeneration > 1_000_000) {
        port.disconnect()
        return
      }
      acceptedPortGeneration = message.portGeneration
      port.postMessage({ type: PORT_HANDSHAKE_ACK,
        portGeneration: acceptedPortGeneration,
        portCurrent: sellerPort === port,
        backgroundActiveJobCandidateId:
          activeJob?.identity?.candidateId ?? "NONE" })
      return
    }
    if (message?.type === "SELLER_OS_GET_LUNA_CAPTURE_CAPABILITY_V1") {
      void reportCaptureCapability()
      return
    }
    if (message?.type === GET_BINDING_STORAGE_DIAGNOSTIC) {
      void bindingStorageDiagnostic().then((diagnostic) =>
        port.postMessage(diagnostic))
      return
    }
    if (message?.type === GET_CANONICAL_DESTINATION_STATUS) {
      void readDestinationBinding().then((binding) => port.postMessage({
        type: CANONICAL_DESTINATION_STATUS,
        canonicalDestinationBound: Boolean(binding),
        canonicalDestinationMatch: false,
        bindingStatus: binding ? "BINDING_PRESENT_VALID" : "NO_BINDING_PRESENT",
      })).catch((error) => port.postMessage({
        type: CANONICAL_DESTINATION_STATUS,
        error: safeRuntimeReason(error instanceof Error ? error.message
          : "BINDING_STORAGE_READ_FAILED"),
      }))
      return
    }
    if (message?.type === "SELLER_OS_BIND_LUNA_CANONICAL_DESTINATION") {
      void handleCanonicalDestinationBinding(port, message.bootstrapJob)
      return
    }
    if (message?.type === GET_ACTIVE_PRODUCTION_JOB_STATUS) {
      port.postMessage({ type: ACTIVE_PRODUCTION_JOB_STATUS,
        active: Boolean(activeJob),
        lifecycle: lastOwnedContextCleanup,
        ...(activeJob ? { job: activeJob, phase: activeJobPhase,
          dispatchPendingDurableAck: Boolean(pendingExactDispatch),
          dispatchCompleted: Boolean(completedExactDispatchTraceId),
          dispatchMessageReceived: exactDispatchMessageReceivedCandidateId ===
            activeJob.identity.candidateId,
          dispatchAckEmitted: exactDispatchAckEmittedCandidateId ===
            activeJob.identity.candidateId,
          traceEvents: activeRuntimeTrace?.events ?? [] } : {}) })
      if (activeJob && pendingExactDispatch && completedExactDispatchTraceId &&
          exactDispatchAckEmittedCandidateId === activeJob.identity.candidateId) {
        port.postMessage({ type: JOB_DISPATCH_ACK,
          candidateId: activeJob.identity.candidateId,
          traceId: completedExactDispatchTraceId,
          durableDispatchAcknowledged: true,
          extensionAckEmitted: true })
      }
      return
    }
    if (message?.type === "START_SHIPPING_JOB") {
      if (message.requireDurableDispatchAck === true &&
          acceptedPortGeneration === null) {
        port.postMessage({ type: JOB_RESULT, success: false,
          error: "LUNA_SHIPPING_PORT_HANDSHAKE_REQUIRED",
          capture: { candidateId: message.job?.identity?.candidateId ?? null } })
        return
      }
      if (message.portGeneration !== undefined &&
          message.portGeneration !== acceptedPortGeneration) {
        port.postMessage({ type: JOB_RESULT, success: false,
          error: "LUNA_SHIPPING_PORT_GENERATION_MISMATCH",
          capture: { candidateId: message.job?.identity?.candidateId ?? null } })
        return
      }
      const activeJobBeforeStart = activeJob
      void startJob(message.job, message.productionAutoClaim === true,
        false, message.requireDurableDispatchAck === true,
        message.preDispatchTrace ?? null, port, acceptedPortGeneration)
        .catch((error) => {
          if (activeJob && activeJob !== activeJobBeforeStart &&
              sameJob(activeJob, message.job)) {
            failActiveJob(error instanceof Error ? error.message
              : "LUNA_SHIPPING_JOB_FAILED")
            return
          }
          try {
            port.postMessage({ type: JOB_RESULT, success: false,
              error: error instanceof Error ? error.message
                : "LUNA_SHIPPING_JOB_FAILED",
              capture: { candidateId: message.job?.identity?.candidateId ?? null },
            })
          } catch { /* The bridge may have entered BFCache meanwhile. */ }
        })
      return
    }
    if (message?.type === DURABLE_DISPATCH_ACK) {
      const pending = pendingExactDispatch
      const alreadyCompleted = completedExactDispatchTraceId &&
        message.traceId === completedExactDispatchTraceId && activeJob &&
        message.candidateId === activeJob.identity.candidateId
      if (alreadyCompleted) {
        port.postMessage({ type: JOB_DISPATCH_ACK,
          candidateId: activeJob.identity.candidateId,
          traceId: completedExactDispatchTraceId,
          durableDispatchAcknowledged: true,
          extensionAckEmitted: true })
        return
      }
      if (!pending || !activeJob || message.traceId !== pending.traceId ||
          message.candidateId !== pending.candidateId ||
          activeJob.captureSessionId !== pending.captureSessionId) {
        port.postMessage({ type: JOB_RESULT, success: false,
          error: "LUNA_EXACT_DISPATCH_DURABLE_ACK_MISMATCH",
          capture: { candidateId: message.candidateId ?? null } })
        return
      }
      completedExactDispatchTraceId = pending.traceId
      exactDispatchAckEmittedCandidateId = activeJob.identity.candidateId
      port.postMessage({ type: JOB_DISPATCH_ACK,
        candidateId: activeJob.identity.candidateId,
        traceId: completedExactDispatchTraceId,
        durableDispatchAcknowledged: true,
        extensionAckEmitted: true })
      return
    }
    if (message?.type === PAGE_DISPATCH_COMMITTED) {
      const pending = pendingExactDispatch
      if (!pending || !activeJob ||
          message.traceId !== completedExactDispatchTraceId ||
          message.candidateId !== activeJob.identity.candidateId ||
          activeJob.captureSessionId !== pending.captureSessionId) {
        port.postMessage({ type: JOB_RESULT, success: false,
          error: "LUNA_EXACT_DISPATCH_PAGE_COMMIT_MISMATCH",
          capture: { candidateId: message.candidateId ?? null } })
        return
      }
      void navigateActiveJob(pending.url).then(() => {
        if (!activeJob || !pendingExactDispatch ||
            activeJob.captureSessionId !== pending.captureSessionId) return
        pendingExactDispatch = null
      }).catch((error) => failActiveJob(error))
      return
    }
    if (message?.type === SHIPPING_SERVER_RESULT) {
      if (!activeJob || message.candidateId !== activeJob.identity.candidateId) {
        return
      }
      if (message.success !== true) {
        failActiveJob(typeof message.reasonCode === "string"
          ? message.reasonCode : "LUNA_SHIPPING_CAPTURE_SERVER_RESULT_FAILED")
        return
      }
      if (message.terminalDecision === "REJECT_STOCK") {
        emitRuntimeTrace("STOCK_EVIDENCE_RECONCILED", true, "NONE", {
          productOosConfirmed: true,
          productPageStockStatus: "FRESH_OUT_OF_STOCK",
        })
        emitRuntimeTrace("REJECTED_STOCK")
        emitRuntimeTrace("PRODUCTION_JOB_COMPLETED")
        emitRuntimeTrace("AUTO_NEXT")
        emitRuntimeTrace("PASS")
        void terminateActiveJob("SUCCESS_REJECT_STOCK")
        return
      }
      const safeDetails = { subtotalUsd: message.subtotalUsd,
        shippingUsd: message.shippingUsd, totalUsd: message.totalUsd }
      emitRuntimeTrace("CAPTURE_POST", true, "NONE", safeDetails)
      emitRuntimeTrace("DURABLE_READBACK", true, "NONE", safeDetails)
      emitRuntimeTrace("ECONOMICS_EVALUATED", true, "NONE", safeDetails)
      emitRuntimeTrace("PASS", true, "NONE", safeDetails)
      void terminateActiveJob("SUCCESS")
      return
    }
    if (message?.type === CANCEL_ACTIVE_JOB) {
      if (!activeJob || message.captureSessionId !== activeJob.captureSessionId ||
          message.candidateId !== activeJob.identity.candidateId) {
        port.postMessage({ type: JOB_RESULT, success: false,
          error: "LUNA_SHIPPING_CANCEL_IDENTITY_MISMATCH",
          capture: { candidateId: message.candidateId ?? null } })
        return
      }
      failActiveJob("LUNA_SHIPPING_JOB_CANCELLED")
      return
    }
    if (message?.type !== RESUME_ACTIVE_JOB) return
    const invalidReason = jobValidationReason(message.job)
    if (invalidReason || (activeJob && !sameJob(activeJob, message.job))) {
      port.postMessage({ type: JOB_RESULT, success: false,
        error: invalidReason ?? "SERVICE_WORKER_JOB_STATE_NOT_RECOVERED",
        capture: { candidateId: message.job?.identity?.candidateId ?? null } })
      return
    }
    const recoveredFromEmptyWorker = !activeJob
    activeJob = message.job
    activeJobPhase = new Set([CART_PHASE, CHECKOUT_PHASE]).has(message.phase)
      ? message.phase : "PRODUCT_PAGE"
    if (recoveredFromEmptyWorker) armActiveJobTimeout()
    emitProgress("BRIDGE_RECONNECTED")
  })
  port.onDisconnect.addListener(() => {
    // Reading lastError inside the callback prevents Chrome from emitting
    // "Unchecked runtime.lastError" when BFCache closes the external port.
    consumeRuntimeLastError()
    if (sellerPort !== port) return
    sellerPort = null
    // The UI bridge is transport only. The job belongs to the service worker
    // and survives BFCache, ordinary navigation, and page-port replacement.
  })
})

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === GET_CANONICAL_DESTINATION_BINDING) {
    const recovered = recoverActiveJob(sender)
    if (!recovered || !new Set([CART_PHASE, CHECKOUT_PHASE])
        .has(activeJobPhase) ||
        message.captureSessionId !== activeJob.captureSessionId) {
      sendResponse({ accepted: false,
        error: "ACTIVE_JOB_CHECKOUT_CONTINUITY_UNPROVEN" })
      return false
    }
    void readDestinationBinding().then((binding) => sendResponse({
      accepted: true,
      bindingStatus: binding ? "BINDING_PRESENT_VALID" : "NO_BINDING_PRESENT",
      ...(binding ? { binding } : {}),
    })).catch((error) => sendResponse({ accepted: false,
      error: safeRuntimeReason(error instanceof Error ? error.message
        : "BINDING_STORAGE_READ_FAILED") }))
    return true
  }
  if (message?.type === AUTO_BIND_CANONICAL_DESTINATION) {
    const recovered = sender.frameId === 0 && recoverActiveJob(sender)
    if (!recovered || activeJobPhase !== CHECKOUT_PHASE ||
        message.captureSessionId !== activeJob.captureSessionId) {
      sendResponse({ contractVersion: AUTO_BIND_CONTRACT, success: false,
        error: "ACTIVE_JOB_CHECKOUT_CONTINUITY_UNPROVEN" })
      return false
    }
    void autoBindCanonicalDestination(message)
      .then((response) => sendResponse(response))
      .catch((error) => sendResponse({ contractVersion: AUTO_BIND_CONTRACT,
        success: false, error: safeRuntimeReason(error instanceof Error
          ? error.message : "CANONICAL_DESTINATION_AUTO_BIND_FAILED") }))
    return true
  }
  if (message?.type === CHECKOUT_BOOTSTRAP_ACK) {
    if (message.extensionBuildVersion !== EXTENSION_BUILD_VERSION) {
      sendResponse({ accepted: false,
        error: "EXTENSION_ARTIFACT_VERSION_MISMATCH" })
      return false
    }
    const recovered = sender.frameId === 0 && recoverActiveJob(sender)
    if (!recovered || activeJobPhase !== CHECKOUT_PHASE ||
        !checkoutNavigationArmed) {
      sendResponse({ accepted: false, error: sender.frameId === 0
        ? "ACTIVE_JOB_CHECKOUT_CONTINUITY_UNPROVEN" : "WRONG_FRAME_TARGET" })
      return false
    }
    observeCheckoutNavigation({ tabId: sender.tab.id, frameId: 0,
      url: sender.url }, true)
    if (!checkoutNavigationObservation?.observed) {
      sendResponse({ accepted: false,
        error: "CHECKOUT_NAVIGATION_NOT_OBSERVED" })
      return false
    }
    checkoutBootstrapAckReceived = true
    emitCheckoutBootstrapAck()
    if (canonicalBindBootstrapActive) settleCanonicalBindCheckout()
    sendResponse({ accepted: true, captureSessionId: activeJob.captureSessionId })
    return false
  }
  if (message?.type === GET_ACTIVE_JOB) {
    const recovered = recoverActiveJob(sender)
    if (!recovered) {
      sendResponse({ accepted: false,
        error: "SERVICE_WORKER_JOB_STATE_NOT_RECOVERED" })
      return false
    }
    emitProgress("ACTIVE_JOB_REQUESTED")
    sendResponse({ accepted: true, job: recovered, phase: activeJobPhase,
      originalCartSnapshot, cartSubtotalUsd,
      bindingBootstrap: canonicalBindBootstrapActive })
    return false
  }
  if (message?.type === SET_ACTIVE_JOB_PHASE) {
    const recovered = recoverActiveJob(sender)
    const startingCart = message.phase === CART_PHASE
    const startingCheckout = message.phase === CHECKOUT_PHASE &&
      activeJobPhase === CART_PHASE && Array.isArray(originalCartSnapshot) &&
      Number.isFinite(message.cartSubtotalUsd) && message.cartSubtotalUsd >= 0 &&
      message.cartSubtotalUsd <= 100_000
    const snapshot = startingCart
      ? safeCartSnapshot(message.originalCartSnapshot) : originalCartSnapshot
    if (!recovered || (!startingCart && !startingCheckout) || !snapshot ||
        message.captureSessionId !== activeJob.captureSessionId) {
      sendResponse({ accepted: false,
        error: "ACTIVE_JOB_CART_CONTINUITY_UNPROVEN" })
      return false
    }
    activeJobPhase = message.phase
    originalCartSnapshot = snapshot
    if (startingCart) {
      checkoutNavigationArmed = false
      checkoutNavigationTriggered = false
    }
    if (startingCheckout) {
      cartSubtotalUsd = Math.round(message.cartSubtotalUsd * 100) / 100
      checkoutNavigationArmed = true
      checkoutNavigationTriggered = false
      if (!armCheckoutNavigationObserver()) {
        sendResponse({ accepted: false,
          error: "CHECKOUT_NAVIGATION_OBSERVER_NOT_ARMED" })
        return false
      }
    }
    emitProgress(activeJobPhase)
    sendResponse({ accepted: true, phase: activeJobPhase })
    return false
  }
  if (message?.type === CHECKOUT_NAVIGATION_TRIGGER) {
    const recovered = recoverActiveJob(sender)
    if (!recovered || activeJobPhase !== CHECKOUT_PHASE ||
        message.captureSessionId !== activeJob.captureSessionId ||
        !markCheckoutNavigationTriggered()) {
      sendResponse({ accepted: false,
        error: "CHECKOUT_NAVIGATION_NOT_TRIGGERED" })
      return false
    }
    sendResponse({ accepted: true,
      captureSessionId: activeJob.captureSessionId })
    return false
  }
  if (message?.type === JOB_RESUME) {
    const invalidReason = jobValidationReason(message.job)
    if (invalidReason || !Number.isInteger(sender.tab?.id) ||
        (activeJob && !sameJob(activeJob, message.job))) {
      sendResponse({ accepted: false,
        error: invalidReason ?? "SERVICE_WORKER_JOB_STATE_NOT_RECOVERED" })
      return false
    }
    const recoveredFromEmptyWorker = !activeJob
    activeJob = message.job
    activeTabId = sender.tab.id
    if (recoveredFromEmptyWorker) armActiveJobTimeout()
    sendResponse({ accepted: true, captureSessionId: activeJob.captureSessionId })
    return false
  }
  if (message?.type === JOB_PROGRESS && recoverActiveJob(sender) &&
      (!message.captureSessionId ||
        message.captureSessionId === activeJob.captureSessionId) &&
      (!message.candidateId ||
        message.candidateId === activeJob.identity.candidateId) &&
      new Set(["CONTENT_SCRIPT_LOADED", "ACTIVE_JOB_REQUESTED",
        "ACTIVE_JOB_RECOVERED", "PRODUCT_PAGE_DOM_READY",
        "AUTH_EXPLICITLY_FAILED", "AUTH_CHALLENGE_PRESENT",
        "AUTH_NOT_YET_REQUIRED", "AUTHENTICATED_OPERATION_CONFIRMED",
        "PRODUCT_IDENTITY_CHECK_STARTED", "PRODUCT_IDENTITY_VERIFIED",
        "PRODUCT_OOS_CONFIRMED",
        "ADD_TO_CART_ELEMENT_FOUND", "ADD_TO_CART_CLICK_DISPATCHED",
        "AWAITING_CART_CONFIRMATION", "ACTIVE_JOB_RECOVERED_ON_CART",
        "CART_PAGE_DETECTED", "CART_EXPECTED_PRODUCT_FOUND",
        "CART_EXPECTED_QUANTITY_FOUND", "CART_MUTATION_CONFIRMED",
        "BRIDGE_RECONNECTED", "SHIPPING_FLOW_RESUMED",
        "AWAITING_CHECKOUT_SHIPPING", "CHECKOUT_NAVIGATION_ARMED",
        "CHECKOUT_NAVIGATION_TRIGGERED", "CHECKOUT_NAVIGATION_TIMEOUT",
        "CHECKOUT_NAVIGATION_OBSERVED",
        "CHECKOUT_HOST_ALLOWED", "CHECKOUT_INJECTION_REQUESTED",
        "CHECKOUT_INJECTION_API_SUCCEEDED", "CHECKOUT_SCRIPT_INJECTED",
        "CHECKOUT_SCRIPT_BOOTSTRAP_ACK",
        "CHECKOUT_CONTENT_SCRIPT_LOADED",
        "ACTIVE_JOB_RECOVERED_ON_CHECKOUT", "CHECKOUT_CLASSIFIER_STARTED",
        "CHECKOUT_HOST_CLASSIFIED", "SHOP_PAY_DOM_WAITING",
        "SHOP_PAY_DOM_READY", "CHECKOUT_PAGE_CLASSIFIED",
        "CHECKOUT_PAGE_DETECTED", "SHOP_PAY_QUOTE_PARSER_STARTED",
        "NORMAL_GUEST_CHECKOUT", "NORMAL_CHECKOUT_WITH_CONTACT_FORM",
        "NORMAL_CHECKOUT_WITH_SHIPPING_FORM", "NORMAL_CHECKOUT_WITH_SHIPPING",
        "EXPLICIT_LOGIN_PAGE",
        "EXPLICIT_AUTH_CHALLENGE", "SESSION_EXPIRED",
        "UNKNOWN_CHECKOUT_PAGE", "CANONICAL_US_PROFILE_FOUND",
        "SHIPPING_ADDRESS_ACCEPTED", "SHIPPING_OPTIONS_DETECTED",
        "SHIPPING_CAPTURE_STARTED", "SHIPPING_QUOTE_CAPTURED",
        "RESULT_POSTED"]).has(message.state)) {
    if (canonicalBindBootstrapActive) {
      if (message.state === "PRODUCT_IDENTITY_VERIFIED") {
        emitBindBootstrapTraceOnce("BIND_BOOTSTRAP_PRODUCT_VERIFIED")
      } else if (message.state === "CART_MUTATION_CONFIRMED") {
        emitBindBootstrapTraceOnce("BIND_BOOTSTRAP_CART_CONFIRMED")
      } else if (message.state === "CHECKOUT_NAVIGATION_OBSERVED") {
        emitBindBootstrapTraceOnce(
          "BIND_BOOTSTRAP_CHECKOUT_NAVIGATION_OBSERVED")
      }
    }
    emitProgress(message.state, { cartSubtotalUsd: message.cartSubtotalUsd,
      subtotalUsd: message.subtotalUsd,
      shippingUsd: message.shippingUsd,
      totalUsd: message.totalUsd,
      checkoutHostClassification: message.checkoutHostClassification,
      checkoutNavigationHost: message.checkoutNavigationHost,
      checkoutNavigationOrigin: message.checkoutNavigationOrigin,
      checkoutHostPermissionMatch: message.checkoutHostPermissionMatch,
      checkoutPageClassification: message.checkoutPageClassification,
      shopPayMarkerOrderSummary: message.shopPayMarkerOrderSummary,
      shopPayMarkerProduct: message.shopPayMarkerProduct,
      shopPayMarkerQuantity: message.shopPayMarkerQuantity,
      shopPayMarkerShipTo: message.shopPayMarkerShipTo,
      shopPayMarkerShipping: message.shopPayMarkerShipping,
      shopPayMarkerSubtotal: message.shopPayMarkerSubtotal,
      shopPayMarkerShippingAmount: message.shopPayMarkerShippingAmount,
      shopPayMarkerTotal: message.shopPayMarkerTotal,
      shopPayMarkerShippingMethod: message.shopPayMarkerShippingMethod,
      shopPayMarkerPayment: message.shopPayMarkerPayment,
      shopPayMarkerPayNow: message.shopPayMarkerPayNow,
      subtotalLabelFound: message.subtotalLabelFound,
      subtotalAmountCandidateFound: message.subtotalAmountCandidateFound,
      subtotalCurrencyFound: message.subtotalCurrencyFound,
      subtotalParsed: message.subtotalParsed,
      shippingLabelFound: message.shippingLabelFound,
      shippingAmountCandidateFound: message.shippingAmountCandidateFound,
      shippingCurrencyFound: message.shippingCurrencyFound,
      shippingParsed: message.shippingParsed,
      totalLabelFound: message.totalLabelFound,
      totalAmountCandidateFound: message.totalAmountCandidateFound,
      totalCurrencyFound: message.totalCurrencyFound,
      totalParsed: message.totalParsed,
      productOosConfirmed: message.productOosConfirmed,
      productPageStockStatus: message.productPageStockStatus,
      authSignal: message.authSignal,
      authSignalSource: message.authSignalSource })
    return false
  }
  if (message?.type === JOB_RUNTIME_FAILURE && recoverActiveJob(sender)) {
    let error = safeRuntimeReason(message.error)
    if (error === "LUNA_UNKNOWN_CHECKOUT_PAGE") {
      if (!checkoutBootstrapAckEmitted) {
        error = "CHECKOUT_CONTENT_SCRIPT_BOOTSTRAP_NOT_ACKNOWLEDGED"
      } else if (lastCheckoutStateRank < 50) {
        error = "ACTIVE_JOB_CHECKOUT_CONTINUITY_UNPROVEN"
      } else if (lastCheckoutStateRank < 60) {
        error = "CHECKOUT_CLASSIFIER_NOT_STARTED"
      } else if (lastCheckoutStateRank < 70) {
        error = "CHECKOUT_HOST_NOT_CLASSIFIED"
      }
    }
    if (canonicalBindBootstrapActive) {
      settleCanonicalBindCheckout(new Error(error))
    } else {
      failActiveJob(error)
    }
    return false
  }
  if (message?.type !== JOB_RESULT || !sellerPort ||
      sender.tab?.id !== activeTabId || !activeJob) return false
  const capture = message.capture && typeof message.capture === "object"
    ? message.capture : {}
  if (capture.candidateId !== activeJob.identity.candidateId ||
      capture.captureSessionId !== activeJob.captureSessionId ||
      capture.nonce !== activeJob.nonce) return false
  sellerPort.postMessage({ type: JOB_RESULT,
    success: message.success === true,
    ...(message.success === true ? { capture,
      ...(message.terminalDecision === "REJECT_STOCK" &&
        capture.productOosConfirmed === true &&
        capture.productPageStockStatus === "FRESH_OUT_OF_STOCK"
        ? { terminalDecision: "REJECT_STOCK" } : {}) }
      : { error: typeof message.error === "string"
        ? safeRuntimeReason(message.error) : "LUNA_SHIPPING_JOB_FAILED",
        lastRuntimeState, capture }) })
  if (message.success !== true) {
    emitRuntimeTrace("FAIL", false, typeof message.error === "string"
      ? safeRuntimeReason(message.error) : "LUNA_SHIPPING_JOB_FAILED")
    void terminateActiveJob(message.error ?? "LUNA_SHIPPING_JOB_FAILED")
  }
  return false
})

chrome.tabs.onRemoved.addListener((tabId) => {
  const owned = ownedRunTabs.has(tabId)
  if (owned) void forgetOwnedRunTab(tabId)
  if (tabId === activeTabId) {
    activeTabId = null
    if (activeJob && !jobTerminationInProgress) {
      failActiveJob(owned ? "LUNA_SHIPPING_OWNED_TAB_CLOSED"
        : "LUNA_SHIPPING_ACTIVE_TAB_CLOSED")
    }
  }
})

chrome.webNavigation?.onCommitted?.addListener((details) => {
  observeCheckoutNavigation(details, false)
})

chrome.webNavigation?.onCompleted?.addListener((details) => {
  observeCheckoutNavigation(details, true)
})

// Reuse Chrome lifecycle events. A heartbeat never probes or claims Shipping.
chrome.tabs.onUpdated?.addListener?.((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || activeJob || !sellerPort) return
  try {
    const url = new URL(tab.url)
    if (url.protocol === "https:" && url.hostname === "shop.app") void reportCaptureCapability(tabId)
  } catch { /* A non-checkout tab is not a capability transition. */ }
})
